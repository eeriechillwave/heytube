/* =========================================================================
 * HeyGram Cookies — extensão auxiliar do HeyGram (Adobe Premiere Pro)
 * Copyright (c) 2026 Neto Salazar. Todos os direitos reservados.
 *
 * Único propósito: ler os cookies do Instagram já salvos neste navegador
 * (o usuário precisa estar logado) e gerar um arquivo cookies.txt no
 * formato Netscape, que o HeyGram usa para localizar perfis e baixar
 * Reels. Nenhum dado sai deste navegador — o arquivo é salvo localmente.
 * ========================================================================= */
(function () {
  "use strict";

  var api = typeof browser !== "undefined" ? browser : chrome;
  var btn = document.getElementById("downloadBtn");
  var label = btn.querySelector(".btn-label");
  var statusEl = document.getElementById("status");

  var DOMINIOS = ["https://www.instagram.com", "https://instagram.com"];
  var TEXTOS = {
    baixar: "Baixar cookies",
    baixando: "Baixando…",
    pronto: "Cookies baixados!",
    semCookies: "Nenhum cookie encontrado. Você está logado no Instagram neste navegador?",
    erroLeitura: "Não foi possível ler os cookies deste navegador.",
    erroSalvar: "Não foi possível salvar o arquivo cookies.txt.",
  };

  function limparStatus() {
    statusEl.textContent = "";
    statusEl.className = "status";
  }
  function mostrarErro(texto) {
    statusEl.textContent = texto;
    statusEl.className = "status status--error";
  }
  function mostrarSucesso(texto) {
    statusEl.textContent = texto;
    statusEl.className = "status status--ok";
  }

  // Formato Netscape HTTP Cookie File — o mesmo que o yt-dlp/gallery-dl
  // esperam via --cookies. Campos separados por TAB, nesta ordem:
  // domínio / incluir subdomínios / caminho / seguro / validade / nome / valor
  function paraLinhaNetscape(c) {
    var dominio = c.domain || "";
    var incluirSub = dominio.charAt(0) === "." ? "TRUE" : "FALSE";
    var caminho = c.path || "/";
    var seguro = c.secure ? "TRUE" : "FALSE";
    var validade = c.session ? "0" : String(Math.round(c.expirationDate || 0));
    return [dominio, incluirSub, caminho, seguro, validade, c.name, c.value].join("\t");
  }

  function gerarArquivo(cookies) {
    var linhas = [
      "# Netscape HTTP Cookie File",
      "# Gerado automaticamente pela extensão HeyGram Cookies — não editar à mão.",
      "",
    ];
    cookies.forEach(function (c) { linhas.push(paraLinhaNetscape(c)); });
    return linhas.join("\n") + "\n";
  }

  function lerTodosOsCookies() {
    return Promise.all(
      DOMINIOS.map(function (url) { return api.cookies.getAll({ url: url }); })
    ).then(function (listas) {
      var vistos = {}, todos = [];
      listas.forEach(function (lista) {
        (lista || []).forEach(function (c) {
          var chave = c.domain + "|" + c.path + "|" + c.name;
          if (!vistos[chave]) { vistos[chave] = true; todos.push(c); }
        });
      });
      return todos;
    });
  }

  function baixarComoArquivo(conteudo) {
    var blob = new Blob([conteudo], { type: "text/plain" });
    var url = URL.createObjectURL(blob);
    return api.downloads
      .download({
        url: url,
        filename: "HeyGram/Cookies/cookies.txt",
        saveAs: false,
        conflictAction: "overwrite",
      })
      .then(function (id) {
        setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
        return id;
      });
  }

  btn.addEventListener("click", function () {
    if (btn.classList.contains("is-loading")) return;
    limparStatus();
    btn.classList.remove("is-done");
    btn.classList.add("is-loading");
    label.textContent = TEXTOS.baixando;

    lerTodosOsCookies()
      .then(function (cookies) {
        if (!cookies.length) {
          btn.classList.remove("is-loading");
          label.textContent = TEXTOS.baixar;
          mostrarErro(TEXTOS.semCookies);
          return;
        }
        var conteudo = gerarArquivo(cookies);
        return baixarComoArquivo(conteudo).then(function () {
          btn.classList.remove("is-loading");
          btn.classList.add("is-done");
          label.textContent = TEXTOS.pronto;
          mostrarSucesso(TEXTOS.pronto + " (" + cookies.length + " cookies)");
          setTimeout(function () {
            btn.classList.remove("is-done");
            label.textContent = TEXTOS.baixar;
          }, 2200);
        }).catch(function () {
          btn.classList.remove("is-loading");
          label.textContent = TEXTOS.baixar;
          mostrarErro(TEXTOS.erroSalvar);
        });
      })
      .catch(function () {
        btn.classList.remove("is-loading");
        label.textContent = TEXTOS.baixar;
        mostrarErro(TEXTOS.erroLeitura);
      });
  });
})();
