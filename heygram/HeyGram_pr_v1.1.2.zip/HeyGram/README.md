# HeyGram

Extensão para o Adobe Premiere Pro que baixa Reels do Instagram e importa
direto para a sua sequência ativa.

## O que o HeyGram faz

- Cola o link de um Reels e o painel mostra thumbnail, duração, legenda e
  hashtags antes de baixar.
- Busca por tema (aba **Buscar**) ou por perfil público (aba **Perfil**).
- Baixa na melhor qualidade disponível e importa direto para o projeto,
  já inserido na timeline ativa.
- Guarda os Reels baixados e os favoritos na **Biblioteca**, para reusar
  sem precisar baixar de novo.
- Prepara sozinho, na primeira abertura, os componentes gratuitos
  necessários para funcionar — você não precisa instalar nada manualmente.

O HeyGram trabalha apenas com Reels e perfis públicos do Instagram. Posts,
carrosséis, fotos e Stories não são suportados.

## Instalação

1. Extraia o conteúdo deste pacote.
2. Copie a pasta `HeyGram` para:
   `%APPDATA%\Adobe\CEP\extensions\` (Windows).
3. Abra (ou reabra) o Premiere Pro e acesse em
   **Janela → Extensões → HeyGram**.

Se o painel não aparecer, confirme que o Premiere Pro está na versão 25.0
ou mais recente.

## Primeiros passos

Na primeira abertura, o HeyGram vai pedir para você aceitar os termos de
uso e ativar sua licença (com o e-mail e o ID do pedido da sua compra). Em
seguida, ele prepara sozinho os componentes necessários — isso acontece
uma única vez e pode levar alguns minutos, dependendo da sua internet.

### Cookies do Instagram (necessário para buscar e baixar)

O Instagram exige uma sessão autenticada para a maior parte das buscas e
downloads. Por isso, o HeyGram precisa de um arquivo `cookies.txt` do
navegador em que você está logado no Instagram.

A forma mais simples é usando a extensão **HeyGram Cookies**, incluída
neste pacote (pasta `HeyGram-Cookies`): instale-a no seu navegador, clique
em um botão e o arquivo é gerado automaticamente. O passo a passo
completo, explicado de forma bem simples, está em
`HeyGram-Cookies/COMO_INSTALAR.txt`.

Depois de instalada, sempre que o HeyGram precisar de cookies e não
encontrar nenhum configurado, ele mostra um aviso guiando você até o
arquivo.

## Menu de configurações

- **Idioma**: português ou inglês.
- **Acesso ao Instagram**: onde você seleciona o arquivo `cookies.txt`.
- **Desativar este dispositivo**: libera a vaga deste computador na sua
  licença (útil se for usar o HeyGram num PC novo — o limite é de 2
  dispositivos simultâneos).
- **Diagnóstico**: um relatório rápido do ambiente, usado para identificar
  problemas caso algo não funcione como esperado.
- **Abrir pasta de downloads**, **Procurar atualizações** e **Limpar
  cache** também ficam disponíveis ali.

## Suporte

Dúvidas ou problemas: suporte-heyforge@proton.me

Use apenas conteúdo para o qual você tenha autorização e respeite os
termos de serviço do Instagram e os direitos de terceiros.
