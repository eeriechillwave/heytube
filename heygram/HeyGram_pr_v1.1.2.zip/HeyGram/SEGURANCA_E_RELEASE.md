# Segurança e release — HeyGram v1.1.2

Esta versão aplica as correções locais levantadas na auditoria de segurança.

## Corrigido nesta versão

- O plugin aceita apenas URLs HTTPS de **Reels do Instagram**. Links de fotos, carrosséis, Stories, TikTok e endereços HTTP ficam fora do fluxo.
- Metadados locais da biblioteca deixam de ser carregados com `eval`; há um parser estrito de JSON.
- Título, perfil, miniatura e demais metadados vindos da rede são escapados antes de entrarem no HTML. URLs de mídia são restringidas a `https://` e `file:///`.
- O player local usa uma rota temporária com token, ligada somente a `127.0.0.1`, sem CORS aberto. O elemento de vídeo não solicita CORS desnecessariamente.
- As rotinas Deno de detalhes do perfil e busca de Reels só recebem acesso de rede a `instagram.com` e `www.instagram.com`.
- A busca compacta de perfis mantém uma exceção temporária: além do Instagram, ela precisa alcançar os hosts variáveis de CDN que entregam as fotos de perfil. Isso existe apenas para gravar essas fotos no cache de sessão; o endereço retornado ainda é validado antes de ser exibido.
- Caminhos personalizados de mídia e de `cookies.txt` são recusados quando possuem caracteres capazes de alterar comandos externos.
- Diagnósticos não exibem mais o caminho do `cookies.txt`; a escrita de logs redige nomes usuais de cookies de sessão.
- Logs técnicos expiram após 30 dias e ficam limitados a 120 arquivos.
- Atualizações exigem HTTPS, domínio oficial `heytube.net`/`updates.heytube.net` e SHA-256 do ZIP.

## Publicar uma atualização

O manifesto remoto precisa conter o hash SHA-256 real do ZIP publicado:

```json
{
  "version": "1.1.2",
  "notas": "Resumo das alterações.",
  "arquivo": "https://updates.heytube.net/heygram/HeyGram_pr_v1.1.2.zip",
  "sha256": "64_caracteres_hexadecimais_do_zip"
}
```

Gere o hash no Windows com:

```powershell
Get-FileHash -Algorithm SHA256 .\HeyGram_pr_v1.1.2.zip
```

O instalador compara esse valor antes de extrair o arquivo. Uma atualização sem hash válido é recusada.

## Pendências que dependem da infraestrutura de distribuição

1. **Assinatura do feed de atualizações.** O hash no mesmo feed evita erros acidentais, mas não substitui uma assinatura. Para fechar essa camada, o servidor precisa assinar o JSON com uma chave privada mantida fora do plugin; o cliente recebe apenas a chave pública e valida a assinatura antes de ler `arquivo` e `sha256`.
2. **Integridade dos componentes.** `yt-dlp`, FFmpeg, Deno e gallery-dl ainda vêm das fontes configuradas no instalador. A próxima publicação deve substituir URLs `latest` por versões fixadas e um manifesto mantido pela HeyForge com SHA-256 de cada binário.
3. **Licença.** A validação forte exige que o Worker entregue uma licença assinada com expiração e que o cliente valide com chave pública. O Worker e as chaves não fazem parte deste pacote, portanto isso não foi simulado nem ativado nesta versão.

## Cookies

`cookies.txt` é uma credencial de sessão. O HeyGram guarda somente o caminho do arquivo em sua configuração local; não copia o conteúdo para os logs. Mantenha o arquivo em pasta privada, não o envie para suporte e revogue a sessão no Instagram se ele for exposto.
