/* =========================================================================
 * HeyGram — extensao CEP para Adobe Premiere Pro
 * Copyright (c) 2026 Neto Salazar. Todos os direitos reservados.
 *
 * SOFTWARE PROPRIETARIO. Este codigo e confidencial e licenciado, nao
 * vendido. E proibido copiar, modificar, redistribuir, revender, publicar,
 * fazer engenharia reversa ou criar obras derivadas, no todo ou em parte,
 * sem autorizacao escrita do titular.
 *
 * Contato: suporte-heyforge@proton.me
 * ========================================================================= */

(function () {
"use strict";

/* license.js — validacao de licenca do HeyGram (Worker heygram-licenca).
   POST {LICENSE_API_BASE}/validate { orderId, email, deviceId } -> { valid, reason }
   POST {LICENSE_API_BASE}/release  { orderId, email, deviceId } -> { ok }
   Limite de 2 dispositivos simultaneos por licenca.

   CEP roda sem Node aqui (sem --enable-nodejs), entao o cache de licenca e o
   deviceId usam localStorage em vez de arquivos em disco.

   DEVICE_KEY fica separado de LICENSE_KEY de proposito: precisa sobreviver a
   uma desativacao/reativacao neste PC. NUNCA remova DEVICE_KEY ao desativar. */
var LICENSE_API_BASE = "https://licenca-heygram.heytube.net";

var LICENSE_KEY = "heygram.license.v1";
var DEVICE_KEY = "heygram.device.v1";
var TOLERANCIA_OFFLINE_MS = 10 * 24 * 60 * 60 * 1000; // 10 dias
var INTERVALO_REVALIDACAO_MS = 4 * 60 * 60 * 1000; // 4 horas

/* ---------- persistencia local (localStorage do painel) ---------- */

function lerCache() {
  try {
    var bruto = localStorage.getItem(LICENSE_KEY);
    if (!bruto) return null;
    var obj = JSON.parse(bruto);
    return obj && typeof obj === "object" ? obj : null;
  } catch (e) {
    return null;
  }
}

function salvarCache(obj) {
  try { localStorage.setItem(LICENSE_KEY, JSON.stringify(obj)); } catch (e) { /* localStorage indisponivel */ }
}

function removerCache() {
  try { localStorage.removeItem(LICENSE_KEY); } catch (e) { /* ignora */ }
}

/* deviceId: gerado uma unica vez por instalacao e reaproveitado (nunca muda). */
function obterDeviceId() {
  try {
    var bruto = localStorage.getItem(DEVICE_KEY);
    if (bruto) {
      var obj = JSON.parse(bruto);
      if (obj && typeof obj.deviceId === "string" && obj.deviceId) return obj.deviceId;
    }
  } catch (e) {
    /* chave corrompida: gera uma nova abaixo */
  }
  var novo = (typeof crypto !== "undefined" && crypto.randomUUID)
    ? crypto.randomUUID()
    : "dev-" + Date.now().toString(16) + "-" + Math.random().toString(16).slice(2);
  try { localStorage.setItem(DEVICE_KEY, JSON.stringify({ deviceId: novo })); } catch (e) { /* segue sem persistir */ }
  return novo;
}

/* ---------- chamada ao Worker ---------- */

function chamarValidate(orderRef, email) {
  if (!LICENSE_API_BASE) {
    return Promise.reject(new Error("endpoint de licenca ainda nao configurado"));
  }
  return fetch(LICENSE_API_BASE + "/validate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ orderId: orderRef, email: email, deviceId: obterDeviceId() }),
  }).then(function (res) {
    if (!res.ok) throw new Error("HTTP " + res.status);
    return res.json();
  });
}

// chamarRelease(orderRef, email): libera no Worker a vaga ocupada pelo
// deviceId DESTE PC para essa licenca (endpoint /release, ja publicado).
function chamarRelease(orderRef, email) {
  if (!LICENSE_API_BASE) {
    return Promise.reject(new Error("endpoint de licenca ainda nao configurado"));
  }
  return fetch(LICENSE_API_BASE + "/release", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ orderId: orderRef, email: email, deviceId: obterDeviceId() }),
  }).then(function (res) {
    if (!res.ok) throw new Error("HTTP " + res.status);
    return res.json();
  });
}

/* ---------- API publica ---------- */

// ativarLicenca: chama /validate; salva cache local se valid:true.
function ativarLicenca(orderRef, email) {
  var ref = String(orderRef || "").trim();
  var mail = String(email || "").trim();

  return chamarValidate(ref, mail).then(function (resp) {
    if (resp && resp.valid) {
      var cache = {
        orderRef: ref,
        email: mail,
        ultimaValidacaoOk: true,
        ultimaValidacaoEm: Date.now(),
      };
      salvarCache(cache);
      return { valid: true };
    }
    return { valid: false, reason: (resp && resp.reason) || "" };
  });
}

// checarLicencaComCache: roda no boot e periodicamente. Nunca rejeita;
// resolve { bloqueado, motivo, cache, offline }. Offline com cache valido
// dentro de TOLERANCIA_OFFLINE_MS libera; caso contrario bloqueia.
function checarLicencaComCache() {
  var cache = lerCache();

  if (!cache || !cache.orderRef || !cache.email) {
    return Promise.resolve({ bloqueado: true, motivo: "sem_licenca", cache: cache, offline: false });
  }

  return chamarValidate(cache.orderRef, cache.email)
    .then(function (resp) {
      if (resp && resp.valid) {
        var atualizado = {
          orderRef: cache.orderRef,
          email: cache.email,
          ultimaValidacaoOk: true,
          ultimaValidacaoEm: Date.now(),
        };
        salvarCache(atualizado);
        return { bloqueado: false, motivo: null, cache: atualizado, offline: false };
      }
      // Worker recusou: bloqueia sem alterar o cache (preserva a tolerancia offline).
      return { bloqueado: true, motivo: (resp && resp.reason) || "invalida", cache: cache, offline: false };
    })
    .catch(function (erro) {
      var temCacheValido = cache.ultimaValidacaoOk && typeof cache.ultimaValidacaoEm === "number";
      var dentroDaTolerancia = temCacheValido && (Date.now() - cache.ultimaValidacaoEm) <= TOLERANCIA_OFFLINE_MS;
      if (dentroDaTolerancia) {
        return { bloqueado: false, motivo: null, cache: cache, offline: true };
      }
      return {
        bloqueado: true,
        motivo: "offline_expirado",
        cache: cache,
        offline: true,
        erro: String(erro && erro.message ? erro.message : erro),
      };
    });
}

// liberarDispositivo: chama /release; se ok, apaga LICENSE_KEY local
// (DEVICE_KEY sobrevive de proposito).
function liberarDispositivo(orderRef, email) {
  var ref = String(orderRef || "").trim();
  var mail = String(email || "").trim();

  return chamarRelease(ref, mail).then(function (resp) {
    if (resp && resp.ok) {
      removerCache();
      return { ok: true };
    }
    return { ok: false };
  });
}

var license = {
  LICENSE_API_BASE: LICENSE_API_BASE,
  INTERVALO_REVALIDACAO_MS: INTERVALO_REVALIDACAO_MS,
  lerCache: lerCache,
  obterDeviceId: obterDeviceId,
  ativarLicenca: ativarLicenca,
  checarLicencaComCache: checarLicencaComCache,
  liberarDispositivo: liberarDispositivo,
};

window.license = license;

})();
