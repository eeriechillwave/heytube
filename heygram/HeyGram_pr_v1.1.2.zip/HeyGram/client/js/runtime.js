/* HeyGram CEP — ponte entre a casca visual e o host ExtendScript. */
(function () {
  "use strict";

  var cs = typeof CSInterface !== "undefined" ? new CSInterface() : null;
  var selected = null;
  var activeDownloadStamp = "";
  var profileUrl = "", profileCursor = 0, profileLimit = 50, profileWindow = [], profileSelected = {}, profileDetailsLoading = false;
  var downloadLocked = false;
  var coreReady = false, coreBusy = false, coreWaiters = [], coreStepWaiters = [];

  function byId(id) { return document.getElementById(id); }
  function text(key, fallback) {
    try { return (window.T && window.T[currentLang] && window.T[currentLang][key]) || fallback; } catch (e) { return fallback; }
  }
  function escapeScript(value) { return String(value || "").replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/[\r\n]+/g, " "); }
  function host(code, done) {
    if (!cs) { done("ERROR: Abra o HeyGram dentro do Premiere Pro."); return; }
    cs.evalScript(code, function (result) { done(result || ""); });
  }
  // Garante cookies configurados antes de buscar; senao mostra o modal de cookies.
  function ensureCookiesThenRun(fn) {
    return function () {
      if (window.heygramEnsureCookies) { window.heygramEnsureCookies(fn); } else { fn(); }
    };
  }
  function friendlyError(raw) {
    var value = String(raw || "");
    var low = value.toLowerCase();
    if (low.indexOf("yt-dlp") >= 0 && (low.indexOf("não reconhecido") >= 0 || low.indexOf("nao reconhecido") >= 0 || low.indexOf("existe: nao") >= 0)) return "O componente de download não foi instalado. O HeyGram tentará preparar novamente.";
    if (low.indexOf("login required") >= 0 || low.indexOf("private") >= 0) return "Esse conteúdo exige acesso. Configure os cookies no menu de configurações.";
    if (low.indexOf("unsupported url") >= 0) return "Esse endereço não é compatível com esta ação.";
    if (low.indexOf("no video formats") >= 0) return "Não encontrei um vídeo disponível nesse conteúdo.";
    if (low.indexOf("timed out") >= 0 || low.indexOf("tempo esgotado") >= 0) return "A plataforma demorou demais para responder. Tente novamente.";
    return value.indexOf("ERROR:") === 0 ? "Não foi possível concluir. Abra Diagnóstico nas configurações para ver os detalhes." : value;
  }
  function updateCoreMessage(message) {
    try { if (window.console && console.info) console.info("[HeyGram] " + message); } catch (e) { }
  }
  function finishCore(error) {
    coreBusy = false;
    coreReady = !error;
    updateCoreMessage(error ? friendlyError(error) : "Componentes prontos para uso.");
    var waiters = coreWaiters.slice();
    coreWaiters = [];
    coreStepWaiters = [];
    for (var i = 0; i < waiters.length; i += 1) waiters[i](error || "");
  }
  // onStep e' opcional (etapa atual do onboarding visivel). Somado a
  // coreStepWaiters pra' avisar tambem quem chamar depois, mesmo com uma
  // instalacao ja em andamento.
  function installCore(onStep) {
    if (onStep) coreStepWaiters.push(onStep);
    if (coreBusy && coreStepWaiters.length > 1) return; // instalacao ja rodando; so' registra o onStep acima.
    coreBusy = true;
    updateCoreMessage("Preparando os componentes do HeyGram…");
    host("dg_startInstall()", function (started) {
      if (started.indexOf("OK|") !== 0) { finishCore(started || "ERROR: Falha ao iniciar a instalação."); return; }
      var files = started.split("|");
      (function pollInstall() {
        host('dg_pollInstall("' + escapeScript(files[1]) + '","' + escapeScript(files[2]) + '")', function (state) {
          var cut = state.indexOf("|"), status = cut >= 0 ? state.slice(0, cut) : "ERROR", detail = cut >= 0 ? state.slice(cut + 1) : state;
          if (status === "RUNNING") {
            updateCoreMessage("Preparando os componentes… " + (detail || ""));
            for (var i = 0; i < coreStepWaiters.length; i += 1) coreStepWaiters[i](detail || "");
            setTimeout(pollInstall, 800);
            return;
          }
          if (status !== "DONE") { finishCore(detail || "ERROR: Falha ao instalar os componentes."); return; }
          host("dg_checkCore()", function (check) { finishCore(check === "OK" ? "" : "ERROR: O componente principal não foi instalado."); });
        });
      }());
    });
  }
  function ensureCore(done, onStep) {
    if (coreReady) { done(""); return; }
    coreWaiters.push(done);
    if (coreBusy) { if (onStep) coreStepWaiters.push(onStep); return; }
    updateCoreMessage("Verificando os componentes do HeyGram…");
    host("dg_checkCore()", function (result) {
      if (result === "OK") { finishCore(""); return; }
      installCore(onStep);
    });
  }
  // Usado pelo wizard de boas-vindas para bloquear o painel ate os componentes
  // ficarem prontos. onDone recebe "" (sucesso) ou "ERROR: ..." (falha).
  // Checa dg_checkBinaries() (os 5, incluindo ffmpeg/ffprobe) em vez de
  // dg_checkCore() (so' os 3 essenciais), senao o wizard some assim que
  // yt-dlp/deno/gallery-dl terminam, mesmo com o ffmpeg ainda baixando.
  window.heygramEnsureCoreVisible = function (onStep, onDone) {
    host("dg_checkBinaries()", function (full) {
      if (full === "OK") { coreReady = true; onDone(""); return; }
      coreWaiters.push(function (err) { onDone(err || ""); });
      installCore(onStep); // registra o onStep mesmo se ja houver instalacao rodando (ver installCore).
    });
  };
  function isVideoUrl(url) {
    return /^https:\/\/(?:www\.)?instagram\.com\/(?:reel|reels)\/[A-Za-z0-9_-]+\/?(?:\?[A-Za-z0-9._~!$&'()*+,;=:@%\/-]*)?$/i.test(String(url || ""));
  }
  function profileUrlFor(value) {
    var raw = String(value || "").trim();
    if (/^https?:\/\/(?:www\.)?instagram\.com\/[A-Za-z0-9._]+\/?(?:\?.*)?$/i.test(raw)) return raw;
    raw = raw.replace(/^@/, "").replace(/\/.*/, "");
    return /^[A-Za-z0-9._]+$/.test(raw) ? "https://www.instagram.com/" + raw + "/" : "";
  }
  function parseEntries(payload) {
    var result = [], seen = {};
    function mediaScore(raw) {
      var ext = String(raw && (raw.extension || raw.ext) || "").toLowerCase();
      var score = 0;
      if (raw && (raw.video_url || raw.video_dash_manifest)) score += 8;
      if (/^(mp4|m4v|mov|webm)$/.test(ext)) score += 6;
      if (raw && (raw.duration || raw.video_duration)) score += 3;
      if (raw && (raw.thumbnail || raw.display_url)) score += 1;
      return score;
    }
    function add(raw, directUrl) {
      if (!raw || typeof raw !== "object" || raw instanceof Array) return;
      var shortcode = raw.post_shortcode || raw.shortcode || raw.code || "";
      var key = String(shortcode || raw.media_id || raw.id || raw.webpage_url || raw.original_url || directUrl || "");
      var looksLikeMedia = shortcode || raw.formats || raw.requested_formats || raw.video_url || raw.video_dash_manifest || raw.extension || raw.ext || raw.webpage_url;
      if (!looksLikeMedia) return;
      if (directUrl && !raw._gallery_direct_url) raw._gallery_direct_url = directUrl;
      // gallery-dl emite resumo e depois o item completo; mantem a versao mais rica.
      if (key && seen.hasOwnProperty(key)) {
        if (mediaScore(raw) > mediaScore(result[seen[key]])) result[seen[key]] = raw;
        return;
      }
      if (key) seen[key] = result.length;
      result.push(raw);
    }
    function walk(value, inheritedUrl) {
      if (!value) return;
      if (value instanceof Array) {
        var direct = inheritedUrl || "";
        for (var a = 0; a < value.length; a += 1) {
          if (typeof value[a] === "string" && /^https?:\/\//i.test(value[a])) direct = value[a];
        }
        for (var b = 0; b < value.length; b += 1) if (typeof value[b] === "object") walk(value[b], direct);
        return;
      }
      if (typeof value !== "object") return;
      var known = value.post_shortcode || value.shortcode || value.formats || value.video_url || value.video_dash_manifest || value.extension || value.ext || value.webpage_url;
      if (known) { add(value, inheritedUrl); return; }
      for (var key in value) if (value.hasOwnProperty(key) && typeof value[key] === "object") walk(value[key], inheritedUrl);
    }
    var textPayload = String(payload || "").replace(/^\s+|\s+$/g, "");
    if (!textPayload) return result;
    try {
      walk(JSON.parse(textPayload), "");
      return result;
    } catch (wholeError) {}
    var lines = textPayload.split("\n");
    for (var i = 0; i < lines.length; i += 1) {
      try { if (lines[i].replace(/^\s+|\s+$/g, "")) walk(JSON.parse(lines[i]), ""); } catch (e) {}
    }
    return result;
  }
  function duration(value) {
    var seconds = Number(value || 0), min = Math.floor(seconds / 60), sec = Math.floor(seconds % 60);
    return seconds ? min + ":" + (sec < 10 ? "0" : "") + sec : "";
  }
  function entryFrom(raw, fallbackUrl) {
    var userInfo = raw.user || raw.owner || raw.profile || {};
    var shortcode = raw.post_shortcode || raw.shortcode || raw.code || "";
    var publicUrl = raw.webpage_url || raw.original_url || "";
    if (!publicUrl && shortcode) publicUrl = "https://www.instagram.com/reel/" + shortcode + "/";
    var extension = String(raw.extension || raw.ext || "").toLowerCase();
    var mediaType = Number(raw.media_type || raw.product_type_id || 0);
    var isVideo = /^(mp4|m4v|mov|webm)$/.test(extension) || Boolean(raw.video_url || raw.video_dash_manifest || raw.is_video === true || mediaType === 2 || raw.duration || raw.video_duration || raw.formats || raw.requested_formats);
    var productType = String(raw.product_type || raw.product_type_id || "").toLowerCase();
    var mediaKind = String(raw.typename || raw.media_type_name || raw.type || "").toLowerCase();
    var isCarousel = Boolean(raw.carousel_media || raw.edge_sidecar_to_children) || /sidecar|carousel|album/.test(mediaKind);
    var isInstagram = /instagram\.com/i.test(publicUrl || fallbackUrl || "https://www.instagram.com/");
    var isReel = isInstagram && !isCarousel && (/\/reels?\//i.test(publicUrl || "") || /reel|clips/.test(productType));
    var description = raw.description || raw.caption || raw.content || "";
    var handle = raw.uploader || raw.channel || raw.uploader_id || raw.username || raw.owner_username || userInfo.username || "";
    return {
      url: publicUrl || fallbackUrl || "",
      title: raw.title || (description ? String(description).replace(/\s+/g, " ").slice(0, 90) : "Reel"),
      handle: handle,
      thumbnail: raw.thumbnail || raw.display_url || raw.preview_url || raw.image_url || "",
      description: description,
      duration: raw.duration || raw.video_duration || 0,
      width: raw.width || raw.video_width || 0,
      height: raw.height || raw.video_height || 0,
      isVideo: isVideo,
      isReel: isReel,
      fullName: raw.full_name || raw.fullname || raw.owner_full_name || userInfo.full_name || "",
      avatar: raw.profile_pic_url || raw.profile_pic_url_hd || raw.avatar_url || userInfo.profile_pic_url_hd || userInfo.profile_pic_url || "",
      posts: raw.media_count || raw.posts_count || userInfo.media_count || (userInfo.edge_owner_to_timeline_media && userInfo.edge_owner_to_timeline_media.count) || 0,
      followers: raw.follower_count || raw.followers || userInfo.follower_count || (userInfo.edge_followed_by && userInfo.edge_followed_by.count) || 0,
      following: raw.following_count || raw.following || userInfo.following_count || (userInfo.edge_follow && userInfo.edge_follow.count) || 0,
      platform: "Instagram"
    };
  }
  function splitCaption(value) {
    var tags = String(value || "").match(/#[^\s#]+/g) || [];
    var caption = String(value || "");
    for (var i = 0; i < tags.length; i += 1) caption = caption.replace(tags[i], "");
    return { caption: caption.replace(/\s+/g, " ").replace(/^\s+|\s+$/g, ""), tags: tags.join(" ") };
  }
  function escapeHtml(value) {
    return String(value || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  // URLs externas nunca entram como CSS sem validação. Isto evita que um
  // metadado malicioso feche url("...") e injete regras no painel.
  function safeAssetUrl(value) {
    var url = String(value || "").replace(/^\s+|\s+$/g, "");
    if (!/^(?:https:\/\/|file:\/\/\/)/i.test(url)) return "";
    if (/[\u0000-\u001F"'()<>\\\\]/.test(url)) return "";
    return url;
  }
  function cssBackground(value) {
    var url = safeAssetUrl(value);
    return url ? 'url("' + url + '")' : "";
  }
  function pollInfo(stamp, done) {
    var until = Date.now() + 90000;
    (function check() {
      if (Date.now() > until) { done("ERROR: Tempo esgotado ao analisar o link."); return; }
      host('dg_pollFetchInfoByStamp("' + escapeScript(stamp) + '")', function (result) {
        var cut = result.indexOf("|");
        var state = cut >= 0 ? result.slice(0, cut) : "ERROR";
        var payload = cut >= 0 ? result.slice(cut + 1) : result;
        if (state === "RUNNING") { setTimeout(check, 700); return; }
        if (state !== "DONE") { done(friendlyError(payload)); return; }
        done("", parseEntries(payload));
      });
    }());
  }
  function fetchInfo(url, start, end, done) {
    ensureCore(function (coreError) {
      if (coreError) { done(friendlyError(coreError)); return; }
      var args = 'dg_startFetchInfo("' + escapeScript(url) + '"';
      if (start) args += "," + start + "," + end;
      args += ")";
      host(args, function (started) {
        if (started.indexOf("OK|") !== 0) { done(friendlyError(started || "ERROR: Não foi possível iniciar a análise.")); return; }
        pollInfo(started.slice(3), done);
      });
    });
  }
  function fetchReelsSearch(query, done) {
    ensureCore(function (coreError) {
      if (coreError) { done(friendlyError(coreError)); return; }
      host('dg_startReelSearch("' + escapeScript(query) + '")', function (started) {
        if (started.indexOf("OK|") !== 0) { done(friendlyError(started || "ERROR: Não foi possível buscar Reels.")); return; }
        var stamp = started.slice(3), until = Date.now() + 30000;
        (function check() {
          if (Date.now() > until) { done("A busca de Reels demorou demais para responder."); return; }
          host('dg_pollReelSearchByStamp("' + escapeScript(stamp) + '")', function (result) {
            var cut = result.indexOf("|"), state = cut >= 0 ? result.slice(0, cut) : "ERROR", payload = cut >= 0 ? result.slice(cut + 1) : result;
            if (state === "RUNNING") { setTimeout(check, 350); return; }
            if (state !== "DONE") { done(friendlyError(payload)); return; }
            try { var parsed = JSON.parse(payload); done("", parsed && parsed.reels instanceof Array ? parsed.reels : []); }
            catch (e) { done("A resposta da busca de Reels não pôde ser lida."); }
          });
        }());
      });
    });
  }
  function fetchProfileMatches(query, done) {
    ensureCore(function (coreError) {
      if (coreError) { done(friendlyError(coreError)); return; }
      host('dg_startProfileSearch("' + escapeScript(query) + '")', function (started) {
        if (started.indexOf("OK|") !== 0) { done(friendlyError(started || "ERROR: Não foi possível iniciar a busca de perfis.")); return; }
        var stamp = started.slice(3), until = Date.now() + 30000;
        (function check() {
          if (Date.now() > until) { done("A busca de perfis demorou demais para responder."); return; }
          host('dg_pollProfileSearchByStamp("' + escapeScript(stamp) + '")', function (result) {
            var cut = result.indexOf("|"), state = cut >= 0 ? result.slice(0, cut) : "ERROR", payload = cut >= 0 ? result.slice(cut + 1) : result;
            if (state === "RUNNING") { setTimeout(check, 600); return; }
            if (state !== "DONE") { done(friendlyError(payload)); return; }
            try {
              var parsed = JSON.parse(payload), users = parsed && parsed.users instanceof Array ? parsed.users : [];
              if (parsed && parsed.error) { done("A busca de perfis não foi aceita agora: " + parsed.error); return; }
              done("", users);
            } catch (e) { done("A resposta da busca de perfis não pôde ser lida."); }
          });
        }());
      });
    });
  }
  function fetchProfileDetails(username, done) {
    host('dg_startProfileDetails("' + escapeScript(username) + '")', function (started) {
      if (started.indexOf("OK|") !== 0) { done(friendlyError(started || "ERROR: Não foi possível carregar o perfil.")); return; }
      var stamp = started.slice(3), until = Date.now() + 18000;
      (function check() {
        if (Date.now() > until) { done("O perfil demorou demais para responder."); return; }
        host('dg_pollProfileDetailsByStamp("' + escapeScript(stamp) + '")', function (result) {
          var cut = result.indexOf("|"), state = cut >= 0 ? result.slice(0, cut) : "ERROR", payload = cut >= 0 ? result.slice(cut + 1) : result;
          if (state === "RUNNING") { setTimeout(check, 350); return; }
          if (state !== "DONE") { done(friendlyError(payload)); return; }
          try {
            var details = JSON.parse(payload);
            if (details && details.error) { done(details.error); return; }
            done("", details);
          } catch (e) { done("Não foi possível ler os dados do perfil."); }
        });
      }());
    });
  }
  function setDownloadLocked(locked) {
    var overlay = byId("uiLockOverlay"), title = document.querySelector("#screenBaixar .intro__title"), subtitle = document.querySelector("#screenBaixar .intro__subtitle"), panel = document.querySelector(".panel");
    downloadLocked = !!locked;
    if (overlay) overlay.classList.toggle("is-active", !!locked);
    if (panel) panel.classList.toggle("is-download-locked", !!locked);
    if (title) title.textContent = window.heygramText ? window.heygramText(locked ? "baixar_titulo_progresso" : "baixar_titulo") : (locked ? "Baixando seu vídeo agora!" : "Já encontrou seu vídeo?");
    if (subtitle) subtitle.textContent = window.heygramText ? window.heygramText(locked ? "baixar_subtitulo_progresso" : "baixar_subtitulo") : (locked ? "O HeyGram ficará bloqueado até o fim do download ou até você cancelar." : "Cole o link aqui e escolha como deseja baixar.");
  }
  function setDownloadStatus(message, busy, cancellable) {
    var status = byId("downloadStatus"), wrap = byId("downloadProgressWrap"), cancel = byId("downloadCancel"), spinner = byId("downloadSpinner");
    status.textContent = message || "";
    status.classList.toggle("is-hidden", !message);
    wrap.classList.toggle("is-hidden", !busy);
    cancel.classList.toggle("is-hidden", !cancellable);
    if (spinner) spinner.classList.toggle("is-hidden", !(downloadLocked && busy));
  }
  function renderDownloadMeta() {
    var card = byId("downloadMeta"), thumb = byId("downloadThumb"), title = byId("downloadTitle"), meta = byId("downloadMetaLine");
    if (!selected) { card.classList.add("is-hidden"); return; }
    var parts = [selected.handle ? "@" + String(selected.handle).replace(/^@/, "") : "", selected.platform, duration(selected.duration)].filter(Boolean);
    var split = splitCaption(selected.description);
    card.classList.remove("is-hidden");
    title.textContent = selected.title;
    meta.textContent = parts.join(" • ");
    byId("downloadCaption").textContent = split.caption || "Sem legenda disponível.";
    byId("downloadHashtags").textContent = split.tags || "—";
    byId("downloadHashtagLabel").classList.toggle("is-hidden", !split.tags);
    byId("downloadHashtags").classList.toggle("is-hidden", !split.tags);
    thumb.style.backgroundImage = cssBackground(selected.thumbnail);
    thumb.style.backgroundSize = "cover";
    thumb.style.backgroundPosition = "center";
  }
  function analyzeDownload() {
    var url = byId("downloadUrl").value.replace(/^\s+|\s+$/g, "");
    if (!isVideoUrl(url)) { setDownloadStatus("Cole um link válido de Reel do Instagram.", false); return; }
    selected = null;
    renderDownloadMeta();
    setDownloadStatus("Analisando o vídeo…", true, false);
    byId("downloadProgress").style.width = "18%";
    fetchInfo(url, 0, 0, function (error, entries) {
      if (error || !entries || !entries.length) { setDownloadStatus(error || "Não encontrei informações desse vídeo.", false); return; }
      selected = entryFrom(entries[0], url);
      selected.url = isVideoUrl(selected.url) ? selected.url : url;
      renderDownloadMeta();
      byId("downloadProgress").style.width = "100%";
      setDownloadStatus("Vídeo pronto para download.", false);
    });
  }
  function classifyFiles(list) {
    var files = String(list || "").split("\n"), media = "", audioOnly = false, imports = [], videoFiles = [], imageFiles = [];
    for (var i = 0; i < files.length; i += 1) {
      var item = files[i].replace(/^\s+|\s+$/g, "");
      if (!item) continue;
      if (/\.(mp4|mov|mkv|webm|m4v)$/i.test(item)) videoFiles.push(item);
      else if (/\.(mp3|m4a|aac|wav|opus|ogg|flac)$/i.test(item)) { media = item; audioOnly = true; }
      else if (/\.(png|jpe?g)$/i.test(item)) imageFiles.push(item);
    }
    if (videoFiles.length) { media = videoFiles[0]; audioOnly = false; imports = videoFiles.concat(imageFiles); }
    else if (media) imports = [media].concat(imageFiles);
    return { paths: imports, media: media, audioOnly: audioOnly };
  }
  function addToLibrary(media) {
    if (!selected || !window.heygramLibraryAdd) return;
    window.heygramLibraryAdd({
      id: "download_" + Date.now(), title: selected.title, meta: (selected.handle ? "@" + String(selected.handle).replace(/^@/, "") + " • " : "") + selected.platform,
      dur: duration(selected.duration) || "—", added: Date.now(), favorite: false, thumbnail: selected.thumbnail || "",
      mediaPath: media && media.media || "", url: selected.url || "", handle: selected.handle || ""
    });
  }
  function stopActivePlayer() {
    if (window.heygramStopPlayer) { window.heygramStopPlayer(); return; }
    var media = document.querySelectorAll("video, audio");
    for (var i = 0; i < media.length; i += 1) { media[i].pause(); }
  }
  function startDownload() {
    if (!selected || !isVideoUrl(selected.url)) { analyzeDownload(); return; }
    stopActivePlayer();
    ensureCore(function (coreError) {
      if (coreError) { setDownloadStatus(friendlyError(coreError), false); return; }
      var wantThumbnail = byId("swThumb").classList.contains("is-on");
      var audioOnly = byId("swAudio").classList.contains("is-on");
      var profile = String(selected.handle || "social").replace(/^@/, "");
      setDownloadLocked(true);
      setDownloadStatus("Iniciando download…", true, false);
      byId("downloadProgress").style.width = "2%";
      host('dg_startDownload("' + escapeScript(selected.url) + '",' + (wantThumbnail ? "true" : "false") + ',true,"' + escapeScript(profile) + '",' + (audioOnly ? "true" : "false") + ',"' + escapeScript(selected.title || "Reel baixado") + '","' + escapeScript(selected.thumbnail || "") + '","' + escapeScript(duration(selected.duration) || "—") + '")', function (started) {
        if (started.indexOf("OK|") !== 0) { setDownloadLocked(false); setDownloadStatus(friendlyError(started || "Não foi possível iniciar o download."), false, false); return; }
      activeDownloadStamp = started.slice(3);
      var ticks = 0;
      (function poll() {
        if (!activeDownloadStamp) return;
        host('dg_pollDownloadByStamp("' + escapeScript(activeDownloadStamp) + '")', function (state) {
          var cut = state.indexOf("|"), kind = cut >= 0 ? state.slice(0, cut) : "ERROR", data = cut >= 0 ? state.slice(cut + 1) : state;
          if (kind === "RUNNING") {
            ticks += 1;
            var match = data.match(/(\d{1,3}(?:\.\d+)?)%/);
            var percent = match ? Math.min(96, Number(match[1])) : Math.min(92, ticks * 3);
            byId("downloadProgress").style.width = percent + "%";
            setDownloadStatus("Baixando vídeo… " + Math.round(percent) + "%", true, true);
            setTimeout(poll, 1100);
            return;
          }
          var completedStamp = activeDownloadStamp;
          activeDownloadStamp = "";
          if (kind !== "DONE") { setDownloadLocked(false); setDownloadStatus(friendlyError(data || "O download falhou."), false, false); return; }
          var media = classifyFiles(data);
          if (!media.paths.length) { setDownloadLocked(false); setDownloadStatus("Download concluído, mas nenhum arquivo foi localizado.", false, false); return; }
          byId("downloadProgress").style.width = "100%";
          setDownloadStatus("Importando no Premiere…", true, true);
          host('dg_importDownloadResult("' + escapeScript(media.paths.join("||")) + '","' + escapeScript(media.media) + '",' + (media.audioOnly ? "true" : "false") + ',"' + escapeScript(profile) + '","' + escapeScript(completedStamp) + '")', function (imported) {
            addToLibrary(media);
            if (window.heygramPlayCompletionSound) window.heygramPlayCompletionSound();
            setDownloadLocked(false);
            setDownloadStatus(imported.indexOf("OK|") === 0 ? "Download concluído e importado no Premiere." : "Download concluído. Importe o arquivo manualmente.", false, false);
          });
        });
      }());
      });
    });
  }
  function pasteInto(input, after) {
    host("dg_startReadClipboard()", function (started) {
      if (started.indexOf("OK|") !== 0) return;
      var stamp = started.slice(3), deadline = Date.now() + 7000;
      (function poll() {
        if (Date.now() > deadline) return;
        host('dg_pollClipboard("' + escapeScript(stamp) + '")', function (result) {
          var cut = result.indexOf("|"), state = cut >= 0 ? result.slice(0, cut) : "ERROR";
          if (state === "RUNNING") { setTimeout(poll, 150); return; }
          if (state === "DONE") { input.value = result.slice(cut + 1).replace(/^\s+|\s+$/g, ""); if (after) after(); }
        });
      }());
    });
  }
  function renderProfile() {
    var results = byId("profileResults");
    results.innerHTML = profileWindow.map(function (entry) {
      var asset = safeAssetUrl(entry.thumbnail);
      var bg = asset ? ' style="background-image:url(&quot;' + escapeHtml(asset) + '&quot;);background-size:cover;background-position:center"' : "";
      return '<div class="profile-reel" data-url="' + escapeHtml(entry.url) + '"' + bg + '><span class="profile-reel__play">▶</span><span class="profile-reel__duration">' + escapeHtml(duration(entry.duration)) + '</span></div>';
    }).join("");
    results.querySelectorAll(".profile-reel").forEach(function (node, index) {
      node.addEventListener("click", function () {
        selected = profileWindow[index];
        if (window.heygramOpenPlayer) { window.heygramOpenPlayer("perfil", { title: selected.title, meta: (selected.handle ? "@" + selected.handle + " • " : "") + selected.platform, dur: duration(selected.duration), thumbnail: selected.thumbnail, url: selected.url || "", handle: selected.handle || "" }); loadPlayerPreview(selected); }
        else useEntry(selected);
      });
    });
    byId("profileProgress").textContent = profileCursor + " Reels explorados";
    var loaded = byId("profileLoadedCount");
    if (loaded) loaded.textContent = profileCursor ? profileCursor + " Reels carregados" : "";
    byId("profileMoreBtn").textContent = profileCursor >= profileLimit ? "Explorar mais 50" : "Carregar mais";
    byId("profileMoreBtn").classList.remove("is-hidden");
  }
  function formatCount(value) {
    var n = Number(value || 0);
    if (!n) return "—";
    if (n >= 1000000) return (n / 1000000).toFixed(n >= 10000000 ? 0 : 1).replace(".", ",") + " mi";
    if (n >= 1000) return (n / 1000).toFixed(n >= 10000 ? 0 : 1).replace(".", ",") + " mil";
    return String(n);
  }
  function renderProfileInfo(info) {
    info = info || {};
    byId("profileName").textContent = info.full_name || info.username || "Perfil do Instagram";
    byId("profileHandle").textContent = "@" + String(info.username || profileUrl.split("/")[3] || "perfil").replace(/^@/, "");
    var stats = [info.posts || info.media_count, info.followers || info.follower_count, info.following || info.following_count];
    document.querySelectorAll(".profile-stat strong").forEach(function (node, index) {
      node.textContent = profileDetailsLoading && !stats[index] ? "…" : formatCount(stats[index]);
    });
    var avatar = document.querySelector(".profile-card__avatar"), image = info.local_avatar || info.profile_pic_url || info.avatar || "";
    if (avatar) avatar.style.backgroundImage = cssBackground(image);
    var bio = byId("profileBio"), copy = String(info.biography || "").replace(/^\s+|\s+$/g, "");
    bio.textContent = copy; bio.classList.toggle("is-hidden", !copy);
  }
  function renderProfileMatches(users) {
    var box = byId("profileMatches");
    if (!box) return;
    if (!users.length) {
      box.classList.remove("is-hidden");
      box.innerHTML = '<div class="profile-match-status">Nenhum perfil compatível foi encontrado.</div>';
      return;
    }
    box.classList.remove("is-hidden");
    box.innerHTML = '<div class="profile-match-status">Selecione o perfil que você procura:</div>' + users.map(function (user, index) {
      var avatarUrl = safeAssetUrl(user.local_avatar || user.profile_pic_url || "");
      var avatar = avatarUrl ? '<img class="profile-match__avatar" src="' + escapeHtml(avatarUrl) + '" alt="" />' : '<span class="profile-match__avatar is-fallback"></span>';
      var name = user.full_name || user.username;
      var extra = user.is_private ? "Privado" : (user.is_verified ? "Verificado" : "Perfil público");
      return '<button type="button" class="profile-match" data-profile-index="' + index + '">' + avatar + '<span class="profile-match__body"><span class="profile-match__name">' + escapeHtml(name) + '</span><span class="profile-match__handle">@' + escapeHtml(user.username) + '</span></span><span class="profile-match__private">' + extra + '</span></button>';
    }).join("");
    box.querySelectorAll(".profile-match").forEach(function (node) {
      node.addEventListener("click", function () {
        var user = users[Number(node.getAttribute("data-profile-index"))];
        if (user && user.username) openProfile("https://www.instagram.com/" + user.username + "/", user);
      });
    });
  }
  function loadProfilePage() {
    if (!profileUrl) return;
    if (profileCursor >= profileLimit) profileLimit += 50;
    var start = profileCursor + 1, end = Math.min(profileLimit, start + 11);
    byId("profileMoreBtn").classList.add("is-hidden");
    byId("profileSpinner").classList.remove("is-hidden");
    fetchInfo(profileUrl, start, end, function (error, raw) {
      byId("profileSpinner").classList.add("is-hidden");
      if (error) { byId("profileProgress").textContent = error; byId("profileMoreBtn").textContent = "Tentar novamente"; byId("profileMoreBtn").classList.remove("is-hidden"); return; }
      var entries = raw.map(function (item) { return entryFrom(item, ""); }).filter(function (item) { return isVideoUrl(item.url) && item.isVideo && item.isReel; });
      if (!entries.length) {
        byId("profileProgress").textContent = profileCursor ? "Não há mais Reels disponíveis neste perfil." : "Este perfil não possui Reels disponíveis para download.";
        byId("profileMoreBtn").classList.add("is-hidden");
        if (!profileWindow.length) byId("profileReelsHead").classList.add("is-hidden");
        return;
      }
      profileCursor += entries.length;
      profileWindow = profileWindow.concat(entries);
      if (profileWindow.length > 18) profileWindow = profileWindow.slice(-18);
      byId("profileReelsHead").classList.remove("is-hidden");
      var first = entries[0];
      if (first) {
        if (!profileSelected.username && first.handle) profileSelected.username = first.handle;
        if (!profileSelected.full_name && first.fullName) profileSelected.full_name = first.fullName;
        if (!profileSelected.profile_pic_url && first.avatar) profileSelected.profile_pic_url = first.avatar;
        if (!profileSelected.posts && first.posts) profileSelected.posts = first.posts;
        if (!profileSelected.followers && first.followers) profileSelected.followers = first.followers;
        if (!profileSelected.following && first.following) profileSelected.following = first.following;
      }
      renderProfileInfo(profileSelected);
      renderProfile();
    });
  }
  function openProfile(targetUrl, profileData) {
    var nextUrl = targetUrl || profileUrlFor(byId("profileInput").value);
    if (!nextUrl) { byId("profileProgress").textContent = "Informe um @perfil ou link público do Instagram."; return; }
    profileUrl = nextUrl; profileCursor = 0; profileLimit = 50; profileWindow = []; profileSelected = profileData || { username: nextUrl.split("/")[3] }; profileDetailsLoading = true;
    byId("profileMatches").classList.add("is-hidden");
    byId("profileBack").classList.toggle("is-hidden", !profileData);
    renderProfileInfo(profileSelected);
    byId("profileResults").innerHTML = "";
    byId("profileReelsHead").classList.add("is-hidden");
    byId("profilePanel").classList.remove("is-hidden"); byId("profileMoreBtn").classList.add("is-hidden"); byId("profileSpinner").classList.remove("is-hidden");
    fetchProfileDetails(profileSelected.username || nextUrl.split("/")[3], function (error, details) {
      profileDetailsLoading = false;
      if (!error && details) { for (var key in details) if (details.hasOwnProperty(key)) profileSelected[key] = details[key]; }
      renderProfileInfo(profileSelected);
    });
    loadProfilePage();
  }
  function searchProfiles() {
    var query = String(byId("profileInput").value || "").replace(/^\s+|\s+$/g, "");
    var matchBox = byId("profileMatches");
    if (/^https?:\/\//i.test(query)) { openProfile(profileUrlFor(query)); return; }
    if (query.replace(/^@/, "").length < 2) {
      matchBox.classList.remove("is-hidden");
      matchBox.innerHTML = '<div class="profile-match-status">Digite pelo menos dois caracteres para buscar.</div>';
      return;
    }
    byId("profilePanel").classList.add("is-hidden");
    matchBox.classList.remove("is-hidden");
    matchBox.innerHTML = '<div class="search-loading-state"><div class="search-loading-state__spinner" aria-hidden="true"></div><span>' + escapeHtml(text("buscando_perfis", "Buscando perfis…")) + '</span></div>';
    fetchProfileMatches(query.replace(/^@/, ""), function (error, users) {
      if (error) { matchBox.innerHTML = '<div class="profile-match-status">' + escapeHtml(error) + '</div>'; return; }
      renderProfileMatches(users || []);
    });
  }
  function useEntry(entry) {
    stopActivePlayer();
    selected = entry;
    byId("downloadUrl").value = entry.url;
    renderDownloadMeta();
    var baixar = byId("tabBaixar");
    if (baixar) baixar.click();
  }
  function loadPlayerPreview(entry) {
    if (!entry || !isVideoUrl(entry.url)) return;
    host('dg_startPreview("' + escapeScript(entry.url) + '")', function (started) {
      if (started.indexOf("OK|") !== 0) return;
      var stamp = started.slice(3), until = Date.now() + 60000;
      (function check() {
        if (Date.now() > until) return;
        host('dg_pollPreviewByStamp("' + escapeScript(stamp) + '")', function (result) {
          var cut = result.indexOf("|"), state = cut >= 0 ? result.slice(0, cut) : "ERROR", payload = cut >= 0 ? result.slice(cut + 1) : result;
          if (state === "RUNNING") { setTimeout(check, 450); return; }
          // <video> do CEF abre HTTP local direto; evita XHR que pode ser bloqueado.
          if (state === "DONE" && selected === entry && window.heygramLoadPlayerPreview) window.heygramLoadPlayerPreview(payload);
        });
      }());
    });
  }
  function setupSearch() {
    var oldInput = byId("searchInput"), oldButton = byId("searchBtn");
    var input = oldInput.cloneNode(true), button = oldButton.cloneNode(true);
    oldInput.parentNode.replaceChild(input, oldInput); oldButton.parentNode.replaceChild(button, oldButton);
    var moreButton = byId("searchMoreBtn"), searchState = { id: 0, target: "", cursor: 1, entries: [], keys: {}, loading: false, exhausted: false };
    function showMessage(message) {
      var grid = byId("resultsGrid"), more = byId("searchLoadMore");
      grid.classList.remove("is-hidden");
      grid.classList.remove("search-reels");
      grid.innerHTML = '<div class="lib-list is-empty"></div>';
      grid.firstChild.textContent = message;
      more.classList.add("is-hidden");
    }
    function showLoading() {
      var grid = byId("resultsGrid"), more = byId("searchLoadMore");
      grid.classList.remove("is-hidden");
      grid.classList.remove("search-reels");
      grid.innerHTML = '<div class="search-loading-state"><div class="search-loading-state__spinner" aria-hidden="true"></div><span>' + escapeHtml(text("buscando_reels", "Buscando Reels…")) + '</span></div>';
      more.classList.add("is-hidden");
    }
    function renderEntries(entries) {
      var grid = byId("resultsGrid"), more = byId("searchLoadMore"), visible = searchState.visible || 9;
      if (!entries.length) { if (searchState.loading) showLoading(); else showMessage(text("nenhum_reel", "Nenhum Reel foi encontrado para essa busca.")); return; }
      grid.classList.remove("is-hidden");
      grid.classList.add("search-reels");
      grid.innerHTML = entries.slice(0, visible).map(function (entry) {
        var asset = safeAssetUrl(entry.thumbnail);
        var thumbStyle = asset ? ' style="background-image:url(&quot;' + escapeHtml(asset) + '&quot;);background-size:cover;background-position:center"' : "";
        return '<div class="search-reel"' + thumbStyle + '><span class="search-reel__play">▶</span><span class="search-reel__duration">' + escapeHtml(duration(entry.duration)) + '</span></div>';
      }).join("");
      grid.querySelectorAll(".search-reel").forEach(function (card, index) {
        card.addEventListener("click", function () {
          selected = entries[index];
          if (window.heygramOpenPlayer) { window.heygramOpenPlayer("buscar", { title: selected.title, meta: (selected.handle ? "@" + selected.handle + " • " : "") + selected.platform, dur: duration(selected.duration), thumbnail: selected.thumbnail, url: selected.url || "", handle: selected.handle || "" }); loadPlayerPreview(selected); }
          else useEntry(selected);
        });
      });
      more.classList.toggle("is-hidden", searchState.exhausted && searchState.entries.length <= visible);
      moreButton.textContent = searchState.loading ? text("carregando", "Carregando…") : text("carregar_mais", "Carregar mais");
    }
    function appendUnique(raw) {
      raw.map(function (item) { return entryFrom(item, ""); }).filter(function (entry) { return isVideoUrl(entry.url) && entry.isVideo && entry.isReel; }).forEach(function (entry) {
        var key = entry.url || entry.id || entry.title;
        if (!searchState.keys[key]) { searchState.keys[key] = true; searchState.entries.push(entry); }
      });
    }
    function loadUntil(targetCount) {
      if (searchState.loading || searchState.exhausted) return;
      var requestId = searchState.id;
      searchState.loading = true;
      renderEntries(searchState.entries);
      fetchReelsSearch(searchState.query, function (error, raw) {
        // Ignora resultado de uma consulta antiga ja substituida.
        if (requestId !== searchState.id) return;
        searchState.loading = false;
        if (error) { if (!searchState.entries.length) showMessage(friendlyError(error)); return; }
        raw = raw || [];
        appendUnique(raw);
        if (searchState.entries.length) renderEntries(searchState.entries);
        searchState.exhausted = true;
        renderEntries(searchState.entries);
      });
    }
    function search() {
      var query = input.value.replace(/^\s+|\s+$/g, "");
      if (!query) { showMessage("Digite o que você quer encontrar."); return; }
      if (/^https?:\/\//i.test(query) || isVideoUrl(query)) {
        showMessage("Use a aba Baixar para analisar links.");
        return;
      }

      // Extrai o primeiro termo significativo da frase como palavra-chave de busca.
      var normalized = query.toLowerCase()
        .replace(/[áàâãä]/g, "a").replace(/[éèêë]/g, "e")
        .replace(/[íìîï]/g, "i").replace(/[óòôõö]/g, "o")
        .replace(/[úùûü]/g, "u").replace(/ç/g, "c")
        .replace(/[^a-z0-9]+/g, " ").replace(/^\s+|\s+$/g, "");
      var ignored = { a: 1, as: 1, o: 1, os: 1, de: 1, da: 1, das: 1, do: 1, dos: 1, e: 1, em: 1, para: 1, por: 1, com: 1, um: 1, uma: 1 };
      var words = normalized.split(/\s+/), keyword = "";
      for (var w = 0; w < words.length; w += 1) {
        if (words[w] && !ignored[words[w]]) { keyword = words[w]; break; }
      }
      if (!keyword) keyword = words[0] || "";
      if (!keyword) { showMessage("Digite um tema para pesquisar."); return; }

      searchState = { id: Date.now(), query: keyword, cursor: 1, entries: [], keys: {}, visible: 9, loading: false, exhausted: false };
      loadUntil(9);
    }
    var searchGated = ensureCookiesThenRun(search);
    button.addEventListener("click", searchGated); input.addEventListener("keydown", function (event) { if (event.key === "Enter") searchGated(); });
    moreButton.addEventListener("click", function () { searchState.visible = (searchState.visible || 9) + 9; if (searchState.exhausted) renderEntries(searchState.entries); else loadUntil(searchState.visible); });
  }
  function init() {
    ["click", "mousedown", "mouseup", "keydown", "wheel", "touchstart"].forEach(function (eventName) {
      document.addEventListener(eventName, function (event) {
        if (!downloadLocked || (event.target && event.target.closest && event.target.closest("#downloadCancel"))) return;
        event.preventDefault(); event.stopImmediatePropagation();
      }, true);
    });
    byId("profilePanel").classList.add("is-hidden");
    // Remove apenas cache tecnico da sessao anterior; biblioteca/logs ficam intactos.
    host("dg_cleanCacheOnSessionStart()", function () {});
    window.heygramUseSelectedEntry = function () { if (selected) useEntry(selected); };
    window.heygramInsertLibraryItem = function (item) {
      if (!item || !item.mediaPath) return;
      host('dg_insertExistingMedia("' + escapeScript(item.mediaPath) + '","' + escapeScript(item.handle || "instagram") + '")', function (result) {
        if (result.indexOf("OK|") === 0) {
          if (window.heygramClosePlayer) window.heygramClosePlayer();
        }
      });
    };
    window.heygramLoadLocalPlayer = function (mediaPath) {
      host('dg_startLocalPlayerFile("' + escapeScript(mediaPath) + '")', function (started) {
        if (started.indexOf("OK|") !== 0) return;
        var stamp = started.slice(3), until = Date.now() + 10000;
        (function check() {
          if (Date.now() > until) return;
          host('dg_pollLocalPlayerFile("' + escapeScript(stamp) + '")', function (result) {
            var cut = result.indexOf("|"), state = cut >= 0 ? result.slice(0, cut) : "ERROR", payload = cut >= 0 ? result.slice(cut + 1) : result;
            if (state === "RUNNING") { setTimeout(check, 200); return; }
            if (state === "DONE" && window.heygramLoadPlayerPreview) window.heygramLoadPlayerPreview(payload);
          });
        }());
      });
    };
    setupSearch();
    var oldProfileInput = byId("profileInput"), oldProfileBtn = byId("profileBtn"), oldMore = byId("profileMoreBtn");
    var profileInput = oldProfileInput.cloneNode(true), profileBtn = oldProfileBtn.cloneNode(true), more = oldMore.cloneNode(true);
    oldProfileInput.parentNode.replaceChild(profileInput, oldProfileInput); oldProfileBtn.parentNode.replaceChild(profileBtn, oldProfileBtn); oldMore.parentNode.replaceChild(more, oldMore);
    var searchProfilesGated = ensureCookiesThenRun(searchProfiles);
    profileBtn.addEventListener("click", searchProfilesGated); profileInput.addEventListener("keydown", function (event) { if (event.key === "Enter") searchProfilesGated(); }); more.addEventListener("click", loadProfilePage);
    byId("profileBack").addEventListener("click", function () {
      byId("profilePanel").classList.add("is-hidden");
      byId("profileMatches").classList.remove("is-hidden");
      byId("profileBack").classList.add("is-hidden");
    });
    var downloadInput = byId("downloadUrl"), analyzeTimer = null;
    function autoAnalyzeDownload() {
      clearTimeout(analyzeTimer);
      var value = downloadInput.value.replace(/^\s+|\s+$/g, "");
      if (!value) { selected = null; renderDownloadMeta(); setDownloadStatus("", false, false); return; }
      if (!isVideoUrl(value)) { setDownloadStatus("Cole um link válido de Reel do Instagram.", false, false); return; }
      analyzeTimer = setTimeout(analyzeDownload, 280);
    }
    downloadInput.addEventListener("input", autoAnalyzeDownload);
    downloadInput.addEventListener("keydown", function (event) { if (event.key === "Enter") { clearTimeout(analyzeTimer); analyzeDownload(); } });
    byId("downloadPasteBtn").addEventListener("click", function () { pasteInto(byId("downloadUrl"), analyzeDownload); });
    byId("downloadClearBtn").addEventListener("click", function () { clearTimeout(analyzeTimer); downloadInput.value = ""; selected = null; renderDownloadMeta(); setDownloadStatus("", false, false); downloadInput.focus(); });
    byId("downloadAction").addEventListener("click", startDownload);
    byId("downloadCancel").addEventListener("click", function () { if (activeDownloadStamp) host('dg_cancelDownload("' + escapeScript(activeDownloadStamp) + '")', function () {}); activeDownloadStamp = ""; setDownloadLocked(false); setDownloadStatus("Download cancelado.", false, false); });
    byId("chooseDestinationBtn").addEventListener("click", function () { host("dg_chooseTempFolder()", function (result) { if (result.indexOf("OK|") === 0) byId("downloadDestination").textContent = result.slice(3); }); });
    byId("openDestinationBtn").addEventListener("click", function () { host("dg_openTempFolder()", function () {}); });
    host("dg_getTempFolder()", function (result) { var mark = result.indexOf("|"); if (mark >= 0 && result.slice(mark + 1)) byId("downloadDestination").textContent = result.slice(mark + 1); });
    host("dg_listSavedMedia()", function (result) {
      if (!window.heygramLibrarySyncPaths) return;
      if (result.indexOf("OKJSON|") === 0) {
        try { window.heygramLibrarySyncPaths(JSON.parse(result.slice(7)) || []); } catch (_) {}
        return;
      }
      if (result.indexOf("OK|") !== 0) return;
      window.heygramLibrarySyncPaths(result.slice(3).split("\n").filter(function (path) { return !!path; }));
    });
    // NAO chama ensureCore()/installCore() aqui: rodar antes do onboarding
    // "rouba" a instalacao e o wizard visivel nunca abre. O onboarding
    // (prepararComponentesBoasVindas -> heygramEnsureCoreVisible) ja cuida disso.
  }
  init();
}());
