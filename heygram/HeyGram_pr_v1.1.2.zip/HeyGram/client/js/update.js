/* HeyGram — atualização independente do HeyTube.
   O feed remoto precisa apontar para ZIP oficial e incluir a integridade:
   { "version":"1.1.2", "notas":"...", "arquivo":"https://heytube.net/...zip", "sha256":"64-hex" } */
(function (global) {
  "use strict";

  var CURRENT_VERSION = "1.1.2";
  var UPDATE_JSON_URL = "https://heytube.net/heygram-version.json";
  var UPDATE_HOSTS = ["heytube.net", "www.heytube.net", "updates.heytube.net"];
  var updateRunning = false;
  function parts(version) { var m = String(version || "").trim().match(/^(\d+)\.(\d+)\.(\d+)/); return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : null; }
  function compare(remote, local) { var a = parts(remote), b = parts(local), i; if (!a || !b) return 0; for (i = 0; i < 3; i += 1) { if (a[i] > b[i]) return 1; if (a[i] < b[i]) return -1; } return 0; }
  function label(key, fallback) { return global.heygramText ? global.heygramText(key) : fallback; }
  function report(message, state) { if (global.heygramUpdateProgress) global.heygramUpdateProgress(message, state || "running"); }
  function hostCall(code, done) { if (typeof CSInterface === "undefined") { done("ERROR: ponte CEP indisponível."); return; } try { (new CSInterface()).evalScript(code, function (result) { done(String(result || "")); }); } catch (error) { done("ERROR: " + String(error)); } }
  function quoted(value) { return String(value || "").replace(/\\/g, "\\\\").replace(/"/g, '\\"'); }
  function validArchive(url) {
    var value = String(url || ""), match = value.match(/^https:\/\/([^\/:?#]+)(?::443)?\/[^\s"'<>]+\.zip(?:[?#][^\s"'<>]*)?$/i);
    if (!match) return false;
    var host = String(match[1] || "").toLowerCase();
    return UPDATE_HOSTS.indexOf(host) >= 0;
  }
  function validSha256(value) { return /^[a-f0-9]{64}$/i.test(String(value || "")); }
  function setBusy(action, later, busy) { action.disabled = busy; later.disabled = busy; action.textContent = busy ? label("update_downloading", "Baixando…") : label("update_button", "Atualizar"); }
  function install(info, action, later) {
    if (updateRunning) return;
    if (!validArchive(info.arquivo) || !validSha256(info.sha256)) { report(label("update_file_missing", "Esta atualização não possui um ZIP oficial com integridade verificada."), "error"); return; }
    updateRunning = true; setBusy(action, later, true); report(label("update_downloading", "Baixando atualização…"), "running");
    hostCall('dg_startPluginUpdate("' + quoted(info.arquivo) + '","' + quoted(info.sha256) + '")', function (start) {
      if (start.indexOf("OK|") !== 0) { updateRunning = false; setBusy(action, later, false); report(label("update_failed", "Não foi possível baixar a atualização."), "error"); return; }
      var stamp = start.slice(3), attempts = 0;
      (function poll() { hostCall('dg_pollPluginUpdate("' + quoted(stamp) + '")', function (response) {
        attempts += 1; var cut = response.indexOf("|"), state = cut >= 0 ? response.slice(0, cut) : "ERROR", message = cut >= 0 ? response.slice(cut + 1) : response;
        if (state === "DONE") { updateRunning = false; setBusy(action, later, false); report(label("update_done", "Atualização concluída. Feche e abra o painel para aplicar."), "done"); return; }
        if (state === "ERROR" || attempts > 180) { updateRunning = false; setBusy(action, later, false); report(message || label("update_failed", "Não foi possível baixar a atualização."), "error"); return; }
        report(message || label("update_downloading", "Baixando atualização…"), "running"); global.setTimeout(poll, 700);
      }); }());
    });
  }
  function setBanner(info) {
    var banner = document.getElementById("updateBanner"), title = document.getElementById("updateBannerTitle"), notes = document.getElementById("updateBannerNotes"), action = document.getElementById("updateBannerAction"), later = document.getElementById("updateBannerLater");
    if (!banner || !title || !notes || !action || !later) return;
    title.textContent = label("update_available", "Uma atualização do HeyGram está disponível") + " · v" + info.version;
    notes.textContent = info.notas || label("update_available_hint", "Baixe a versão mais recente para receber melhorias e correções.");
    action.onclick = function () { install(info, action, later); };
    banner.classList.remove("is-hidden");
  }
  function hideBanner() { var banner = document.getElementById("updateBanner"); if (banner && !updateRunning) banner.classList.add("is-hidden"); }
  function check(manual) {
    if (!global.fetch || !UPDATE_JSON_URL) { if (manual && global.heygramUpdateFeedback) global.heygramUpdateFeedback(false); return Promise.resolve(false); }
    return global.fetch(UPDATE_JSON_URL, { cache: "no-store" }).then(function (response) { if (!response.ok) throw new Error("HTTP " + response.status); return response.json(); }).then(function (data) {
      if (!data || !parts(data.version)) throw new Error("Resposta de atualização inválida");
      var available = compare(data.version, CURRENT_VERSION) > 0;
       if (available) setBanner({ version: String(data.version), notas: String(data.notas || ""), arquivo: String(data.arquivo || ""), sha256: String(data.sha256 || "") }); else hideBanner();
      if (manual && global.heygramUpdateFeedback) global.heygramUpdateFeedback(available); return available;
    }).catch(function () { if (manual && global.heygramUpdateFeedback) global.heygramUpdateFeedback(false, true); return false; });
  }
  global.HeyGramUpdater = { check: check, compare: compare, currentVersion: CURRENT_VERSION, updateUrl: UPDATE_JSON_URL };
}(window));
