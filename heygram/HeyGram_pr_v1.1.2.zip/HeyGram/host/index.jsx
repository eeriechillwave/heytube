// ===================== Utilitários =====================

function isWindows() {
  return $.os.indexOf("Windows") !== -1;
}

function sep() {
  return isWindows() ? "\\" : "/";
}

// Caminhos escolhidos pelo usuário entram depois em scripts .bat/.command.
// Não aceitamos caracteres que alterariam o comando; caminhos normais do
// Windows/macOS continuam aceitos.
function dg_isSafeExternalPath(path) {
  var value = String(path || "");
  if (!value || /[\r\n"]/.test(value)) return false;
  return isWindows() ? !/[&|<>^%!]/.test(value) : !/[$`;&|<>]/.test(value);
}

// Só HTTPS e Reels do Instagram; posts /p/, carrosséis, fotos e Stories ficam fora.
// O sufixo é deliberadamente restrito: não deixa aspas, espaços ou operadores de
// shell chegarem aos scripts .bat/.command que chamam os extratores.
var HG_IG_QUERY = "(?:\\?[A-Za-z0-9._~!$&'()*+,;=:@%\\/-]*)?";
function isSupportedVideoUrl(url) {
  return new RegExp("^https:\\/\\/(?:www\\.)?instagram\\.com\\/(?:reel|reels)\\/[A-Za-z0-9_-]+\\/?" + HG_IG_QUERY + "$", "i").test(String(url || ""));
}

function isInstagramProfileUrl(url) {
  return new RegExp("^https:\\/\\/(?:www\\.)?instagram\\.com\\/[A-Za-z0-9._]+\\/?" + HG_IG_QUERY + "$", "i").test(String(url || ""));
}

function isInstagramTagUrl(url) {
  return new RegExp("^https:\\/\\/(?:www\\.)?instagram\\.com\\/explore\\/tags\\/[A-Za-z0-9._-]+\\/?" + HG_IG_QUERY + "$", "i").test(String(url || ""));
}

function isInstagramListingUrl(url) {
  return isInstagramProfileUrl(url) || isInstagramTagUrl(url);
}

function getBinDir() {
  var dir = new Folder(Folder.userData.fsName + sep() + "HeyGram" + sep() + "bin");
  if (!dir.exists) dir.create();
  return dir.fsName;
}

function getConfigDir() {
  var dir = new Folder(Folder.userData.fsName + sep() + "HeyGram" + sep() + "config");
  if (!dir.exists) dir.create();
  return dir.fsName;
}

// Guarda só o caminho em texto simples: ExtendScript não expõe JSON.parse/stringify.
function readTempFolderSetting() {
  var f = new File(getConfigDir() + sep() + "tempfolder.txt");
  if (!f.exists) return "";
  f.open("r");
  var c = f.read();
  f.close();
  c = c.replace(/^\s+|\s+$/g, "");
  return dg_isSafeExternalPath(c) ? c : "";
}

// ===================== Duas pastas, com papéis distintos =====================
// getWorkDir()  — arquivos técnicos, SEMPRE em %APPDATA%\HeyGram\cache
//                 (nunca na pasta escolhida pelo usuário). "Limpar cache" esvazia isto.
// getMediaDir() — só os vídeos, na pasta escolhida pelo usuário. "Abrir pasta" abre isto.

function getWorkDir() {
  var dir = new Folder(Folder.userData.fsName + sep() + "HeyGram" + sep() + "cache");
  if (!dir.exists) dir.create();
  return dir.fsName;
}

// Logs ficam separados do cache para "Limpar cache" nunca apagar o que serve pra investigar falhas.
function getLogsDir() {
  var root = new Folder(Folder.userData.fsName + sep() + "HeyGram");
  if (!root.exists) root.create();
  var dir = new Folder(root.fsName + sep() + "logs");
  if (!dir.exists) dir.create();

  try {
    var guide = new File(dir.fsName + sep() + "00_LEIA_PRIMEIRO.txt");
    guide.encoding = "UTF-8";
    guide.open("w");
    guide.writeln("HEYGRAM - PASTA DE LOGS");
    guide.writeln("");
    guide.writeln("Envie ao Codex os arquivos mais recentes relacionados ao erro.");
    guide.writeln("analysis_*.txt          = busca, perfil e leitura de metadados");
    guide.writeln("analysis_*_result.jsonl = resposta completa do extrator");
    guide.writeln("download_*.txt          = yt-dlp, FFmpeg, codec e importacao no Premiere");
    guide.writeln("install_*.txt           = instalacao dos componentes");
    guide.writeln("diagnostic_*.txt        = ambiente completo do painel e do Premiere");
    guide.writeln("");
    guide.writeln("Os logs nao contem o conteudo do arquivo cookies.txt.");
    guide.writeln("Logs tecnicos sao mantidos por ate 30 dias (maximo de 120 arquivos).");
    guide.close();
  } catch (e) {}

  dg_pruneLogs(dir);

  return dir.fsName;
}

// Retenção limitada: suporte continua possível sem transformar a pasta de logs
// em histórico permanente de URLs, caminhos locais e mensagens de ferramentas.
function dg_pruneLogs(dir) {
  try {
    var files = dir.getFiles(function (item) {
      return item instanceof File && /^(analysis|download|install|diagnostic|profile|reel)_/i.test(item.name || "");
    });
    var now = new Date().getTime();
    var kept = [];
    for (var i = 0; i < files.length; i++) {
      var age = now - files[i].modified.getTime();
      if (age > 30 * 24 * 60 * 60 * 1000) { try { files[i].remove(); } catch (ignoreAge) {} }
      else kept.push(files[i]);
    }
    kept.sort(function (a, b) { return b.modified.getTime() - a.modified.getTime(); });
    for (var j = 120; j < kept.length; j++) { try { kept[j].remove(); } catch (ignoreCount) {} }
  } catch (e) {}
}

function appendLogFile(path, message) {
  try {
    var f = new File(path);
    f.encoding = "UTF-8";
    if (!f.open("a")) return false;
    f.writeln(dg_redactSensitiveText(message));
    f.close();
    return true;
  } catch (e) {
    return false;
  }
}

// Logs ajudam no suporte, mas não devem conservar tokens de sessão nem o
// caminho completo do arquivo de cookies.
function dg_redactSensitiveText(message) {
  var text = String(message || "");
  text = text.replace(/((?:sessionid|csrftoken|ds_user_id|ig_did)\s*[=:]\s*)[^\s;"']+/gi, "$1[REDACTED]");
  text = text.replace(/--cookies\s+"[^"]+"/gi, "--cookies [arquivo configurado]");
  return text;
}

// Pasta Vídeos do usuário, com fallbacks (a temporária do sistema é esvaziada
// pelo Windows sozinha, não serve pra mídia; OneDrive pode redirecionar ~/Videos).
function getDefaultMediaBase() {
  var candidates = [
    Folder("~/Videos"),
    Folder("~/Vídeos"),
    Folder("~/Movies"),      // macOS
    Folder("~/Documents"),
    Folder.myDocuments
  ];
  for (var i = 0; i < candidates.length; i++) {
    try { if (candidates[i] && candidates[i].exists) return candidates[i]; } catch (e) {}
  }
  return Folder.temp;
}

function getMediaDir() {
  var custom = readTempFolderSetting();
  var base = getDefaultMediaBase();
  if (custom) {
    var customFolder = new Folder(custom);
    if (customFolder.exists) base = customFolder;
  }
  // create() não cria níveis intermediários de forma confiável em todas as
  // versões do ExtendScript, então o pai vem primeiro.
  var parent = new Folder(base.fsName + sep() + "HeyGram");
  if (!parent.exists) parent.create();
  var dir = new Folder(parent.fsName + sep() + "Reels");
  if (!dir.exists) dir.create();

  // Rede de segurança: se a config salva não terminar em HeyGram\Reels, cai no padrão.
  if (!/HeyGram[\\\/]Reels[\\\/]?$/i.test(dir.fsName)) {
    var safe = new Folder(getDefaultMediaBase().fsName + sep() + "HeyGram" + sep() + "Reels");
    if (!safe.exists) safe.create();
    return safe.fsName;
  }

  return dir.fsName;
}

function readLastLine(logPath) {
  return readLastLines(logPath, 1);
}

function readLastLines(logPath, n) {
  var f = new File(logPath);
  if (!f.exists) return "";
  f.encoding = "UTF-8";
  f.open("r");
  var content = f.read();
  f.close();
  var lines = content.split("\n");
  var nonEmpty = [];
  for (var i = 0; i < lines.length; i++) {
    var t = lines[i].replace(/^\s+|\s+$/g, "");
    if (t !== "") nonEmpty.push(t);
  }
  return nonEmpty.slice(-n).join("\n");
}

// ===================== Pasta temporária (config) =====================

function dg_setTempFolder(path) {
  try {
    if (path) {
      if (!dg_isSafeExternalPath(path)) return "ERROR: Escolha uma pasta sem caracteres especiais no nome.";
      var folder = new Folder(path);
      if (!folder.exists) return "ERROR: Pasta inválida.";
    }
    var f = new File(getConfigDir() + sep() + "tempfolder.txt");
    f.open("w");
    f.write(path || "");
    f.close();
    return "OK|" + getMediaDir();
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

function dg_resetTempFolder() {
  return dg_setTempFolder("");
}

function dg_getTempFolder() {
  var custom = readTempFolderSetting();
  if (custom && new Folder(custom).exists) return "CUSTOM|" + getMediaDir();
  return "DEFAULT|" + getMediaDir();
}

function dg_chooseTempFolder() {
  var folder = Folder.selectDialog("Selecione a pasta onde o HeyGram vai salvar os arquivos");
  if (!folder) return "CANCEL";
  return dg_setTempFolder(folder.fsName);
}

// No Windows, Folder.execute() abre o Explorer atrás do Premiere (SO não rouba
// foco); usamos um .vbs com AppActivate pra trazer a janela pra frente. No mac
// o Folder.execute() já abre o Finder em primeiro plano.
function abrirPastaEmPrimeiroPlano(path) {
  if (!isWindows()) { new Folder(path).execute(); return; }
  try {
    var nomePasta = path.replace(/[\\\/]+$/, "").split(/[\\\/]/).pop();
    var vbsPath = getWorkDir() + sep() + "abrir_pasta_" + Date.now() + ".vbs";
    var vbs = new File(vbsPath);
    vbs.open("w");
    vbs.writeln('CreateObject("WScript.Shell").Run "explorer.exe ""' + path + '""", 1, False');
    vbs.writeln("WScript.Sleep 400");
    vbs.writeln('CreateObject("WScript.Shell").AppActivate("' + nomePasta.replace(/"/g, '""') + '")');
    vbs.close();
    vbs.execute();
  } catch (e) {
    new Folder(path).execute();
  }
}

function dg_openTempFolder() {
  try {
    var reels = new Folder(getMediaDir());
    if (!reels.exists) reels.create();
    if (!reels.exists) return "ERROR: Pasta não encontrada.";
    abrirPastaEmPrimeiroPlano(reels.fsName);
    return "OK";
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

function dg_openLogsFolder() {
  try {
    var logs = new Folder(getLogsDir());
    if (!logs.exists) logs.create();
    if (!logs.exists) return "ERROR: Pasta de logs não encontrada.";
    abrirPastaEmPrimeiroPlano(logs.fsName);
    return "OK|" + logs.fsName;
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

function dg_openDownloadsFolder() {
  try {
    var downloads = new Folder(Folder.desktop.parent.fsName + sep() + "Downloads");
    if (!downloads.exists) downloads = Folder.desktop;
    abrirPastaEmPrimeiroPlano(downloads.fsName);
    return "OK|" + downloads.fsName;
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

function dg_clearLogs() {
  try {
    var logs = new Folder(getLogsDir());
    if (!logs.exists) { logs.create(); return "OK|0"; }
    var files = logs.getFiles();
    var removed = 0;
    for (var i = 0; i < files.length; i += 1) {
      if (files[i] instanceof File) {
        try { if (files[i].remove()) removed += 1; } catch (_) {}
      }
    }
    return "OK|" + removed;
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

// Esvazia recursivamente a pasta de cache (subpastas: profile_avatars, prévias do player, etc).
function dg_emptyCacheFolder(folder) {
  var report = { removed: 0, bytes: 0 };
  if (!folder || !folder.exists) return report;
  var children = folder.getFiles();
  for (var i = 0; i < children.length; i++) {
    var child = children[i];
    if (child instanceof Folder) {
      var nested = dg_emptyCacheFolder(child);
      report.removed += nested.removed;
      report.bytes += nested.bytes;
      try { child.remove(); } catch (eFolder) {}
      continue;
    }
    var size = 0;
    try { size = child.length || 0; } catch (eSize) {}
    try { if (child.remove()) { report.removed++; report.bytes += size; } } catch (eFile) {}
  }
  return report;
}

// Limpeza ao abrir o painel: cache técnico da sessão anterior. Reels e logs ficam intactos.
function dg_cleanCacheOnSessionStart() {
  try {
    var folder = new Folder(getWorkDir());
    if (!folder.exists) return "OK|0|0";
    var report = dg_emptyCacheFolder(folder);
    return "OK|" + report.removed + "|" + report.bytes;
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

function dg_cleanTemp() { return dg_cleanCacheOnSessionStart(); }

function dg_clearCache() {
  try {
    var folder = new Folder(getWorkDir());
    if (!folder.exists) return "OK|0|0";
    var report = dg_emptyCacheFolder(folder);
    return "OK|" + report.removed + "|" + report.bytes;
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

// ===================== Ícone da pasta (só Windows) =====================
// O Windows só lê o desktop.ini se ele estiver oculto+sistema E a pasta tiver
// atributo +r. Feito via .bat (não ExtendScript direto) porque sobrescrever um
// arquivo já oculto+sistema falha, e o .bat pode remover os atributos antes.
function dg_applyFolderIcon(extensionPath) {
  try {
    if (!isWindows()) return "SKIP|so-windows";

    var s = sep();
    var brandDir = new Folder(getMediaDir()).parent;   // <base>\HeyGram
    if (!brandDir || !brandDir.exists) return "ERROR: pasta não encontrada.";

    var iniFile = new File(brandDir.fsName + s + "desktop.ini");
    if (iniFile.exists) return "OK|ja-aplicado";

    var srcIcon = new File(String(extensionPath || "").replace(/[\\\/]+$/, "") +
                           s + "client" + s + "icons" + s + "heygram-folder.ico");
    if (!srcIcon.exists) return "ERROR: ícone não encontrado em " + srcIcon.fsName;

    // Cópia num caminho estável: se a extensão for movida ou atualizada, o
    // ícone da pasta continua resolvendo.
    var appDir = new Folder(Folder.userData.fsName + s + "HeyGram");
    if (!appDir.exists) appDir.create();
    var icoPath = appDir.fsName + s + "icon.ico";

    var tmp = getWorkDir();
    var stamp = "icon_" + String(new Date().getTime());
    var bat = new File(tmp + s + stamp + ".bat");
    var dir = brandDir.fsName;
    var ini = dir + "\\desktop.ini";

    bat.open("w");
    bat.writeln("@echo off");
    bat.writeln('copy /y "' + srcIcon.fsName + '" "' + icoPath + '" >nul 2>&1');
    // Remove os atributos antes de reescrever, senão o redirecionamento falha.
    bat.writeln('attrib -h -s -r "' + ini + '" >nul 2>&1');
    bat.writeln('> "' + ini + '" echo [.ShellClassInfo]');
    bat.writeln('>> "' + ini + '" echo IconResource=' + icoPath + ',0');
    bat.writeln('>> "' + ini + '" echo IconFile=' + icoPath);
    bat.writeln('>> "' + ini + '" echo IconIndex=0');
    bat.writeln('>> "' + ini + '" echo InfoTip=Reels baixados pelo HeyGram');
    bat.writeln('attrib +h +s "' + ini + '" >nul 2>&1');
    bat.writeln('attrib +r "' + dir + '" >nul 2>&1');
    // O cache de ícones do Windows é preguiçoso; sem isso a mudança pode só
    // aparecer no próximo logon.
    bat.writeln('ie4uinit.exe -show >nul 2>&1');
    bat.close();

    runHiddenWindows(bat);
    return "OK|aplicado";
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

// ===================== Idioma da interface (config) =====================

function dg_getLanguage() {
  try {
    var f = new File(getConfigDir() + sep() + "language.txt");
    if (!f.exists) return "pt";
    f.open("r");
    var v = f.read();
    f.close();
    v = v.replace(/^\s+|\s+$/g, "");
    return (v === "en") ? "en" : "pt";
  } catch (e) {
    return "pt";
  }
}

function dg_setLanguage(lang) {
  try {
    var value = (lang === "en") ? "en" : "pt";
    var f = new File(getConfigDir() + sep() + "language.txt");
    f.open("w");
    f.write(value);
    f.close();
    return "OK";
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

// ===================== Sessão do navegador (cookies) =====================
// Instagram exige sessão autenticada pra maior parte da extração; o yt-dlp
// reaproveita os cookies de um navegador local via --cookies-from-browser.
function readCookiesBrowserSetting() {
  var f = new File(getConfigDir() + sep() + "cookies_browser.txt");
  if (!f.exists) return "";
  f.open("r");
  var v = f.read();
  f.close();
  v = v.replace(/^\s+|\s+$/g, "");
  return /^(chrome|edge|firefox|brave|opera|vivaldi|safari)$/i.test(v) ? v.toLowerCase() : "";
}

function dg_getCookiesBrowser() {
  var v = readCookiesBrowserSetting();
  return v || "none";
}

function dg_setCookiesBrowser(browser) {
  try {
    var value = /^(chrome|edge|firefox|brave|opera|vivaldi|safari)$/i.test(browser || "") ? browser.toLowerCase() : "";
    var f = new File(getConfigDir() + sep() + "cookies_browser.txt");
    f.open("w");
    f.write(value);
    f.close();
    return "OK|" + (value || "none");
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

// Chrome/Edge/Brave no Windows criptografam os cookies (App-Bound Encryption);
// --cookies-from-browser falha para eles. Só Firefox funciona direto; os demais
// precisam de um cookies.txt exportado.
function readCookiesFileSetting() {
  var f = new File(getConfigDir() + sep() + "cookies_file.txt");
  if (!f.exists) return "";
  f.open("r");
  var v = f.read();
  f.close();
  v = v.replace(/^\s+|\s+$/g, "");
  if (!v) return "";
  if (!dg_isSafeExternalPath(v)) return "";
  return new File(v).exists ? v : "";
}

function dg_getCookiesFile() {
  var v = readCookiesFileSetting();
  return v ? ("OK|" + v) : "NONE|";
}

function dg_setCookiesFile(path) {
  try {
    if (path && !dg_isSafeExternalPath(path)) return "ERROR: Escolha um arquivo sem caracteres especiais no nome.";
    if (path && !new File(path).exists) return "ERROR: Arquivo não encontrado.";
    var f = new File(getConfigDir() + sep() + "cookies_file.txt");
    f.open("w");
    f.write(path || "");
    f.close();
    return "OK|" + (path || "");
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

function dg_chooseCookiesFile() {
  var f = File.openDialog("Selecione o arquivo cookies.txt exportado do navegador");
  if (!f) return "CANCEL";
  return dg_setCookiesFile(f.fsName);
}

// Abre o diálogo já em Downloads/HeyGram/Cookies (onde a extensão salva o
// cookies.txt), com fallback pra Downloads/HeyGram e depois Downloads.
function dg_chooseCookiesFileFromDownloads() {
  try {
    var downloads = new Folder(Folder.desktop.parent.fsName + sep() + "Downloads");
    var comExtensao = new Folder(downloads.fsName + sep() + "HeyGram" + sep() + "Cookies");
    var pastaHeyGram = new Folder(downloads.fsName + sep() + "HeyGram");
    if (comExtensao.exists) Folder.current = comExtensao;
    else if (pastaHeyGram.exists) Folder.current = pastaHeyGram;
    else if (downloads.exists) Folder.current = downloads;
  } catch (e) { /* segue com a pasta atual se isso falhar */ }
  return dg_chooseCookiesFile();
}

function dg_clearCookiesFile() {
  return dg_setCookiesFile("");
}

// "Tem cookies" = arquivo cookies.txt configurado OU leitura direta do Firefox habilitada.
function dg_hasCookies() {
  if (readCookiesFileSetting()) return "YES";
  return readCookiesBrowserSetting() ? "YES" : "NO";
}

// O arquivo cookies.txt tem prioridade sobre o navegador: se o usuário se deu
// ao trabalho de exportar, é porque a extração direta do navegador falhou.
function cookiesArg() {
  var file = readCookiesFileSetting();
  if (file) return ' --cookies "' + file + '"';
  var browser = readCookiesBrowserSetting();
  return browser ? " --cookies-from-browser " + browser : "";
}

// Deno portátil salvo em bin/, caminho explícito pra não depender de PATH.
function denoPath() {
  return getBinDir() + sep() + (isWindows() ? "deno.exe" : "deno");
}

function galleryPath() {
  return getBinDir() + sep() + (isWindows() ? "gallery-dl.exe" : "gallery-dl");
}

function jsRuntimeArg() {
  var deno = denoPath();
  return new File(deno).exists ? ' --js-runtimes "deno:' + deno + '"' : "";
}

// ===================== Diagnóstico =====================

// Chamada mínima: se não responder, o problema é na ponte CEP<->ExtendScript.
function dg_ping() {
  return "PONG";
}

// Cada etapa isolada num try próprio pra uma falha não derrubar o relatório inteiro.
function dg_diag() {
  var out = [];
  var diagStamp = String(new Date().getTime());
  function line(k, v) { out.push(k + ": " + v); }

  try { line("SO", $.os); } catch (e) { line("SO", "ERRO " + e); }
  try { line("Versao ExtendScript", $.version); } catch (e) { line("Versao ExtendScript", "ERRO " + e); }
  try { line("Premiere", app.version); } catch (e) { line("Premiere", "ERRO " + e); }

  var bin = "";
  try { bin = getBinDir(); line("Pasta bin", bin); } catch (e) { line("Pasta bin", "ERRO " + e); }

  var tmp = "";
  try { tmp = getWorkDir(); line("Pasta de trabalho", tmp); } catch (e) { line("Pasta de trabalho", "ERRO " + e); }
  try { line("Pasta de midia", getMediaDir()); } catch (e) { line("Pasta de midia", "ERRO " + e); }

  try {
    var s = sep();
    line("yt-dlp", new File(bin + s + (isWindows() ? "yt-dlp.exe" : "yt-dlp")).exists ? "encontrado" : "AUSENTE");
    line("ffmpeg", new File(bin + s + (isWindows() ? "ffmpeg.exe" : "ffmpeg")).exists ? "encontrado" : "AUSENTE");
    line("ffprobe", new File(bin + s + (isWindows() ? "ffprobe.exe" : "ffprobe")).exists ? "encontrado" : "AUSENTE");
    line("deno", new File(denoPath()).exists ? "encontrado" : "AUSENTE");
    line("gallery-dl", new File(galleryPath()).exists ? "encontrado" : "AUSENTE");
    line("Runtime JS", new File(denoPath()).exists ? "deno:" + denoPath() : "AUSENTE");
  } catch (e) { line("Binarios", "ERRO " + e); }

  // Escrita de arquivo: é o que dg_startFetchInfo faz antes de qualquer coisa.
  try {
    var probe = new File(tmp + sep() + "diag_probe.txt");
    var opened = probe.open("w");
    if (!opened) {
      line("Escrita na pasta temp", "FALHOU ao abrir para escrita");
    } else {
      probe.writeln("ok");
      probe.close();
      line("Escrita na pasta temp", probe.exists ? "ok" : "FALHOU (arquivo nao criado)");
      probe.remove();
    }
  } catch (e) { line("Escrita na pasta temp", "ERRO " + e); }

  // Lançamento de processo externo: o passo mais provável de ser barrado por
  // antivírus ou política de grupo, e o que o painel não consegue enxergar.
  try {
    var stamp = diagStamp;
    var marker = tmp + sep() + "diag_exec_" + stamp + ".txt";
    if (isWindows()) {
      var bat = new File(tmp + "\\diag_exec_" + stamp + ".bat");
      bat.open("w");
      bat.writeln("@echo off");
      bat.writeln('echo EXEC_OK > "' + marker + '"');
      bat.close();
      runHiddenWindows(bat);
    } else {
      var shf = new File(tmp + "/diag_exec_" + stamp + ".command");
      shf.open("w");
      shf.writeln("#!/bin/bash");
      shf.writeln('echo EXEC_OK > "' + marker + '"');
      shf.close();
      shf.execute();
    }
    line("Teste de execucao", "disparado — confira com dg_diagExecResult(\"" + stamp + "\")");
    out.push("__EXEC_STAMP__=" + stamp);
  } catch (e) { line("Teste de execucao", "ERRO " + e); }

  try { line("Cookies", readCookiesFileSetting() ? "arquivo configurado" : (readCookiesBrowserSetting() || "(nenhum)")); } catch (e) { line("Cookies", "ERRO " + e); }

  var report = out.join("\n");
  try {
    var diagPath = getLogsDir() + sep() + "diagnostic_" + diagStamp + ".txt";
    var diagFile = new File(diagPath);
    diagFile.encoding = "UTF-8";
    diagFile.open("w");
    diagFile.writeln("=== HEYGRAM DIAGNOSTIC " + diagStamp + " ===");
    diagFile.writeln(report);
    diagFile.close();
    report += "\nArquivo de log: " + diagPath;
  } catch (eLog) {
    report += "\nFalha ao salvar diagnóstico: " + eLog.toString();
  }

  return report;
}

// Se o marcador não existe, o Premiere não conseguiu lançar processos externos.
function dg_diagExecResult(stamp) {
  try {
    var marker = new File(getWorkDir() + sep() + "diag_exec_" + stamp + ".txt");
    var result = marker.exists ? "OK" : "FALHOU";
    appendLogFile(getLogsDir() + sep() + "diagnostic_" + stamp + ".txt", "Teste de execucao confirmado: " + result);
    return result;
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

function dg_openLatestLog() {
  try {
    var folder = new Folder(getLogsDir());
    var files = folder.getFiles(function (f) {
      return (f instanceof File) && /^(analysis_|download_|install_|diagnostic_).*\.txt$/i.test(f.name);
    });
    if (!files || files.length === 0) return "ERROR: Nenhum log encontrado ainda.";
    var newest = files[0];
    for (var i = 1; i < files.length; i++) {
      if (files[i].modified > newest.modified) newest = files[i];
    }
    newest.execute();
    return "OK|" + newest.fsName;
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

function dg_copyLatestDiagnostic() {
  try {
    if (!isWindows()) return "ERROR: cópia de diagnóstico disponível nesta versão para Windows.";
    var folder = new Folder(getLogsDir());
    var files = folder.getFiles(function (f) { return (f instanceof File) && /^diagnostic_.*\.txt$/i.test(f.name); });
    if (!files || files.length === 0) return "ERROR: Nenhum diagnóstico foi encontrado ainda.";
    var newest = files[0];
    for (var i = 1; i < files.length; i += 1) if (files[i].modified > newest.modified) newest = files[i];
    var tmp = getWorkDir(), stamp = String(new Date().getTime());
    var ps = new File(tmp + sep() + "copy_diagnostic_" + stamp + ".ps1");
    ps.encoding = "UTF-8";
    if (!ps.open("w")) return "ERROR: Não foi possível preparar a cópia.";
    ps.writeln('$ErrorActionPreference = "Stop"');
    ps.writeln('$content = Get-Content -LiteralPath \'' + dg_psQuote(newest.fsName) + '\' -Raw -Encoding UTF8');
    ps.writeln('Set-Clipboard -Value $content');
    ps.close();
    var bat = new File(tmp + sep() + "copy_diagnostic_" + stamp + ".bat");
    bat.open("w");
    bat.writeln("@echo off");
    bat.writeln('powershell -NoProfile -Sta -ExecutionPolicy Bypass -File "' + ps.fsName + '"');
    bat.close();
    runHiddenWindows(bat);
    return "OK|" + newest.fsName;
  } catch (e) { return "ERROR: " + e.toString(); }
}

// ===================== Área de transferência =====================
// navigator.clipboard exige secure context (https/localhost); um painel CEP é
// servido de file://, então a leitura vai pelo host: Get-Clipboard/pbpaste.
function dg_startReadClipboard() {
  try {
    var tmp = getWorkDir();
    var s = sep();
    var stamp = "clip_" + String(new Date().getTime());
    var outFile = tmp + s + stamp + ".txt";
    var doneFile = tmp + s + stamp + "_done.txt";

    if (isWindows()) {
      var bat = new File(tmp + "\\" + stamp + ".bat");
      bat.open("w");
      bat.writeln("@echo off");
      // -Encoding ascii evita o BOM que o Out-File utf8 grava (link do IG é sempre ASCII).
      bat.writeln('powershell -NoProfile -Command "Get-Clipboard -Raw | Out-File -LiteralPath \'' + outFile + '\' -Encoding ascii"');
      bat.writeln('echo DONE > "' + doneFile + '"');
      bat.close();
      runHiddenWindows(bat);
    } else {
      var shf = new File(tmp + "/" + stamp + ".command");
      shf.open("w");
      shf.writeln("#!/bin/bash");
      shf.writeln('pbpaste > "' + outFile + '"');
      shf.writeln('echo DONE > "' + doneFile + '"');
      shf.close();
      shf.execute();
    }

    return "OK|" + stamp;
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

function dg_pollClipboard(stamp) {
  try {
    var tmp = getWorkDir();
    var s = sep();
    if (!new File(tmp + s + stamp + "_done.txt").exists) return "RUNNING|";

    var f = new File(tmp + s + stamp + ".txt");
    var content = "";
    if (f.exists) {
      f.open("r");
      content = f.read();
      f.close();
    }
    content = content.replace(/^﻿/, "").replace(/^\s+|\s+$/g, "");

    var junk = [stamp + ".txt", stamp + "_done.txt", stamp + ".bat", stamp + ".vbs", stamp + ".command"];
    for (var i = 0; i < junk.length; i++) {
      try { var j = new File(tmp + s + junk[i]); if (j.exists) j.remove(); } catch (e2) {}
    }

    return "DONE|" + content;
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

// ===================== Instalação dos binários =====================

// File.execute() num .bat abre CMD visível; rodamos via .vbs (WScript.Shell.Run,
// windowstyle=0) pra ficar oculto.
function runHiddenWindows(batFile) {
  var vbsPath = batFile.fsName.replace(/\.bat$/i, ".vbs");
  var vbs = new File(vbsPath);
  vbs.open("w");
  vbs.writeln('CreateObject("WScript.Shell").Run "cmd.exe /c ""' + batFile.fsName + '""", 0, False');
  vbs.close();
  vbs.execute();
}

// ===================== Atualização do próprio plugin =====================
// Baixa e descompacta o ZIP no cache; só substitui os arquivos se a estrutura CEP for válida.
function dg_pluginRoot() {
  try { return new File($.fileName).parent.parent.fsName; }
  catch (e) { return ""; }
}

function dg_psQuote(value) {
  return String(value || "").replace(/'/g, "''");
}

function dg_validUpdateUrl(url) {
  var value = String(url || "");
  var match = value.match(/^https:\/\/([^\/:?#]+)(?::443)?\/[^\s"'<>]+\.zip(?:[?#][^\s"'<>]*)?$/i);
  if (!match) return false;
  var host = String(match[1] || "").toLowerCase();
  return host === "heytube.net" || host === "www.heytube.net" || host === "updates.heytube.net";
}

function dg_validSha256(value) {
  return /^[a-f0-9]{64}$/i.test(String(value || ""));
}

function dg_updateStatusFile(stamp) {
  return getWorkDir() + sep() + "plugin_update_" + String(stamp) + ".status.txt";
}

function dg_startPluginUpdate(zipUrl, expectedSha256) {
  try {
    if (!isWindows()) return "ERROR|A atualização automática está disponível nesta versão para Windows.";
    if (!dg_validUpdateUrl(zipUrl)) return "ERROR|O endereço do arquivo de atualização é inválido.";
    if (!dg_validSha256(expectedSha256)) return "ERROR|A atualização não possui SHA-256 válido.";
    var root = dg_pluginRoot();
    if (!root || !new Folder(root).exists) return "ERROR|Não foi possível localizar a pasta do HeyGram.";
    var tmp = getWorkDir(), s = sep(), stamp = String(new Date().getTime());
    var statusFile = dg_updateStatusFile(stamp);
    var zipFile = tmp + s + "plugin_update_" + stamp + ".zip";
    var stageDir = tmp + s + "plugin_update_" + stamp;
    var ps = new File(tmp + s + "plugin_update_" + stamp + ".ps1");
    ps.encoding = "UTF-8";
    if (!ps.open("w")) return "ERROR|Não foi possível preparar a atualização.";
    ps.writeln('$ErrorActionPreference = "Stop"');
    ps.writeln('$status = \'' + dg_psQuote(statusFile) + '\'');
    ps.writeln('$zip = \'' + dg_psQuote(zipFile) + '\'');
    ps.writeln('$stage = \'' + dg_psQuote(stageDir) + '\'');
    ps.writeln('$target = \'' + dg_psQuote(root) + '\'');
    ps.writeln('$url = \'' + dg_psQuote(zipUrl) + '\'');
    ps.writeln('$expectedSha256 = \'' + dg_psQuote(String(expectedSha256).toLowerCase()) + '\'');
    ps.writeln('function Set-HeyGramStatus([string]$state, [string]$message) { Set-Content -LiteralPath $status -Value ($state + "|" + $message) -Encoding UTF8 }');
    ps.writeln('try {');
    ps.writeln('  Set-HeyGramStatus "RUNNING" "Baixando atualização…"');
    ps.writeln('  Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $zip');
    ps.writeln('  if ((Get-Item -LiteralPath $zip).Length -lt 1024) { throw "O pacote baixado está vazio ou incompleto." }');
    ps.writeln('  $actualSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $zip).Hash.ToLowerInvariant()');
    ps.writeln('  if ($actualSha256 -ne $expectedSha256) { throw "A integridade do pacote não foi confirmada." }');
    ps.writeln('  Set-HeyGramStatus "RUNNING" "Preparando atualização…"');
    ps.writeln('  Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue');
    ps.writeln('  Expand-Archive -LiteralPath $zip -DestinationPath $stage -Force');
    ps.writeln('  $payload = Join-Path $stage "HeyGram"');
    ps.writeln('  if (-not (Test-Path -LiteralPath (Join-Path $payload "CSXS\\manifest.xml"))) { throw "O ZIP não contém um pacote HeyGram válido." }');
    ps.writeln('  if (-not (Test-Path -LiteralPath (Join-Path $payload "client\\index.html"))) { throw "O ZIP não contém a interface do HeyGram." }');
    ps.writeln('  if (-not (Test-Path -LiteralPath (Join-Path $payload "host\\index.jsx"))) { throw "O ZIP não contém o host CEP." }');
    ps.writeln('  Set-HeyGramStatus "RUNNING" "Instalando atualização…"');
    ps.writeln('  Get-ChildItem -LiteralPath $payload -Force | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $target -Recurse -Force }');
    ps.writeln('  Set-HeyGramStatus "DONE" "Atualização concluída. Feche e abra o painel para aplicar."');
    ps.writeln('} catch { Set-HeyGramStatus "ERROR" $_.Exception.Message }');
    ps.close();
    var bat = new File(tmp + s + "plugin_update_" + stamp + ".bat");
    bat.open("w");
    bat.writeln("@echo off");
    bat.writeln("chcp 65001 >nul");
    bat.writeln('powershell -NoProfile -ExecutionPolicy Bypass -File "' + ps.fsName + '"');
    bat.close();
    runHiddenWindows(bat);
    return "OK|" + stamp;
  } catch (e) { return "ERROR|" + e.toString(); }
}

function dg_pollPluginUpdate(stamp) {
  try {
    var status = new File(dg_updateStatusFile(stamp));
    if (!status.exists) return "RUNNING|Preparando atualização…";
    status.encoding = "UTF-8";
    if (!status.open("r")) return "RUNNING|Preparando atualização…";
    var value = status.read();
    status.close();
    return String(value || "RUNNING|Preparando atualização…").replace(/^\s+|\s+$/g, "");
  } catch (e) { return "ERROR|" + e.toString(); }
}

// Exige os cinco binários: ffmpeg mescla vídeo+áudio do DASH do Instagram,
// ffprobe revela o codec (decide se o Premiere abre o arquivo), Deno é o
// runtime do yt-dlp, gallery-dl é fallback para perfis/temas.
function dg_checkBinaries() {
  try {
    var bin = getBinDir();
    var s = sep();
    var ytdlp = new File(bin + s + (isWindows() ? "yt-dlp.exe" : "yt-dlp"));
    var ffmpeg = new File(bin + s + (isWindows() ? "ffmpeg.exe" : "ffmpeg"));
    var ffprobe = new File(bin + s + (isWindows() ? "ffprobe.exe" : "ffprobe"));
    var deno = new File(bin + s + (isWindows() ? "deno.exe" : "deno"));
    var gallery = new File(bin + s + (isWindows() ? "gallery-dl.exe" : "gallery-dl"));
    return (ytdlp.exists && ffmpeg.exists && ffprobe.exists && deno.exists && gallery.exists) ? "OK" : "MISSING";
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

// Verificação mínima pós-instalação: sem ffmpeg o painel continua usável, só a recodificação falha.
function dg_checkCore() {
  try {
    var bin = getBinDir();
    var ytdlp = new File(bin + sep() + (isWindows() ? "yt-dlp.exe" : "yt-dlp"));
    var deno = new File(bin + sep() + (isWindows() ? "deno.exe" : "deno"));
    var gallery = new File(bin + sep() + (isWindows() ? "gallery-dl.exe" : "gallery-dl"));
    return (ytdlp.exists && deno.exists && gallery.exists) ? "OK" : "MISSING";
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

// Tamanhos aproximados dos componentes (bytes), so' pra estimar progresso de
// download -- o disco crescendo e' o unico sinal confiavel sem parsear a
// saida do curl.
var TAM_YTDLP = 17.5 * 1024 * 1024;
var TAM_GALLERY = 24 * 1024 * 1024;
var TAM_DENO = 95 * 1024 * 1024;
var TAM_FFMPEG = 100 * 1024 * 1024;

// Usado pelo wizard visivel pra desenhar a barra com % e MB reais, olhando
// o tamanho dos arquivos crescendo em bin/ (zips durante o download,
// depois os .exe apos a extração). Nunca chega a 100% sozinho -- só quando
// dg_pollInstall() confirma DONE (ver prepararComponentesBoasVindas() no client).
function dg_installProgress() {
  try {
    var bin = getBinDir();
    var s = sep();
    function tamanho(nome) {
      var f = new File(bin + s + nome);
      return f.exists ? f.length : 0;
    }
    var ytdlp = tamanho(isWindows() ? "yt-dlp.exe" : "yt-dlp");
    var gallery = tamanho(isWindows() ? "gallery-dl.exe" : "gallery-dl");
    var denoZip = tamanho("deno.zip"), deno = tamanho(isWindows() ? "deno.exe" : "deno");
    var ffZip = tamanho("ffmpeg.zip"), ffmpeg = tamanho(isWindows() ? "ffmpeg.exe" : "ffmpeg");
    var total = TAM_YTDLP + TAM_GALLERY + TAM_DENO + TAM_FFMPEG;
    var baixado =
      Math.min(ytdlp, TAM_YTDLP) +
      Math.min(gallery, TAM_GALLERY) +
      Math.min(Math.max(denoZip, deno ? TAM_DENO : 0), TAM_DENO) +
      Math.min(Math.max(ffZip, ffmpeg ? TAM_FFMPEG : 0), TAM_FFMPEG);
    var pct = total > 0 ? Math.min(99, (baixado / total) * 100) : 0;
    return "OK|" + baixado + "|" + total + "|" + pct.toFixed(1);
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

function dg_startInstall() {
  try {
    var bin = getBinDir();
    var tmp = getWorkDir();
    var s = sep();
    var stamp = String(new Date().getTime());
    var logFile = getLogsDir() + s + "install_" + stamp + ".txt";
    var doneFile = tmp + s + "install_done_" + stamp + ".txt";

    if (isWindows()) {
      // curl.exe (nativo do Windows 10 1803+, sem a barra de progresso que
      // deixa o Invoke-WebRequest do PowerShell muito mais lento) com
      // --parallel baixa todos os componentes faltantes de uma vez, em
      // paralelo. PowerShell só entra depois, pra extrair os .exe de dentro
      // dos .zip (I/O local, nunca foi o gargalo).
      var ps = new File(tmp + "\\install_" + stamp + ".ps1");
      ps.open("w");
      ps.writeln('$ErrorActionPreference = "Stop"');
      ps.writeln('$curlArgs = @("-L", "--silent", "--show-error", "--parallel", "--parallel-max", "4")');
      ps.writeln('$algoBaixando = $false');
      ps.writeln('if (-not (Test-Path -LiteralPath "' + bin + '\\yt-dlp.exe")) { $curlArgs += @("-o", "' + bin + '\\yt-dlp.exe", "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe"); $algoBaixando = $true }');
      ps.writeln('if (-not (Test-Path -LiteralPath "' + bin + '\\gallery-dl.exe")) { $curlArgs += @("-o", "' + bin + '\\gallery-dl.exe", "https://github.com/gdl-org/builds/releases/latest/download/gallery-dl_windows.exe"); $algoBaixando = $true }');
      ps.writeln('if (-not (Test-Path -LiteralPath "' + bin + '\\deno.exe")) { $curlArgs += @("-o", "' + bin + '\\deno.zip", "https://github.com/denoland/deno/releases/latest/download/deno-x86_64-pc-windows-msvc.zip"); $algoBaixando = $true }');
      ps.writeln('$ffmpegFaltando = (-not (Test-Path -LiteralPath "' + bin + '\\ffmpeg.exe")) -or (-not (Test-Path -LiteralPath "' + bin + '\\ffprobe.exe"))');
      ps.writeln('if ($ffmpegFaltando) { $curlArgs += @("-o", "' + bin + '\\ffmpeg.zip", "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip"); $algoBaixando = $true }');
      ps.writeln('if ($algoBaixando) {');
      ps.writeln('  Write-Output "Baixando componentes..."');
      ps.writeln('  & curl.exe @curlArgs');
      ps.writeln('  if ($LASTEXITCODE -ne 0) { throw "curl falhou (codigo $LASTEXITCODE)" }');
      ps.writeln('}');
      ps.writeln('if (Test-Path -LiteralPath "' + bin + '\\deno.zip") {');
      ps.writeln('  Expand-Archive -Path "' + bin + '\\deno.zip" -DestinationPath "' + bin + '\\_deno" -Force');
      ps.writeln('  $dn = Get-ChildItem -Path "' + bin + '\\_deno" -Recurse -Filter deno.exe | Select-Object -First 1');
      ps.writeln('  Copy-Item -Path $dn.FullName -Destination "' + bin + '\\deno.exe" -Force');
      ps.writeln('  Remove-Item -Path "' + bin + '\\deno.zip" -Force -ErrorAction SilentlyContinue');
      ps.writeln('  Remove-Item -Path "' + bin + '\\_deno" -Recurse -Force -ErrorAction SilentlyContinue');
      ps.writeln('  Write-Output "deno instalado"');
      ps.writeln('}');
      ps.writeln('if (-not (Test-Path -LiteralPath "' + bin + '\\yt-dlp.exe")) { throw "yt-dlp nao foi baixado" } else { Write-Output "yt-dlp pronto" }');
      ps.writeln('if (Test-Path -LiteralPath "' + bin + '\\gallery-dl.exe") { & "' + bin + '\\gallery-dl.exe" --version | Out-Null; Write-Output "gallery-dl pronto e validado" }');
      // ffmpeg é best-effort: se o download/extração falhar, não deve
      // derrubar a instalação do yt-dlp, que já é o essencial. Um segundo
      // servidor como reserva se o principal falhar ou vier vazio.
      ps.writeln('try {');
      ps.writeln('  if ($ffmpegFaltando) {');
      ps.writeln('    if ((-not (Test-Path -LiteralPath "' + bin + '\\ffmpeg.zip")) -or ((Get-Item "' + bin + '\\ffmpeg.zip").Length -eq 0)) {');
      ps.writeln('      Write-Output "Servidor principal do ffmpeg falhou, tentando servidor alternativo..."');
      ps.writeln('      & curl.exe -L --silent --show-error -o "' + bin + '\\ffmpeg.zip" "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"');
      ps.writeln('    }');
      ps.writeln('    Expand-Archive -Path "' + bin + '\\ffmpeg.zip" -DestinationPath "' + bin + '\\_extract" -Force');
      ps.writeln('    $ff = Get-ChildItem -Path "' + bin + '\\_extract" -Recurse -Filter ffmpeg.exe | Select-Object -First 1');
      ps.writeln('    Copy-Item -Path $ff.FullName -Destination "' + bin + '\\ffmpeg.exe" -Force');
      // ffprobe vem no mesmo pacote; usado pra checar se o codec (VP9/AV1) abre no Premiere.
      ps.writeln('    $fp = Get-ChildItem -Path "' + bin + '\\_extract" -Recurse -Filter ffprobe.exe | Select-Object -First 1');
      ps.writeln('    if ($fp) { Copy-Item -Path $fp.FullName -Destination "' + bin + '\\ffprobe.exe" -Force }');
      ps.writeln('    Remove-Item -Path "' + bin + '\\ffmpeg.zip" -Force -ErrorAction SilentlyContinue');
      ps.writeln('    Remove-Item -Path "' + bin + '\\_extract" -Recurse -Force -ErrorAction SilentlyContinue');
      ps.writeln('    Write-Output "ffmpeg instalado"');
      ps.writeln('  } else { Write-Output "ffmpeg e ffprobe ja estavam prontos" }');
      ps.writeln('} catch { Write-Warning "Não foi possível preparar o ffmpeg; algumas conversões podem ficar indisponíveis." }');
      ps.close();

      var bat = new File(tmp + "\\install_" + stamp + ".bat");
      bat.open("w");
      bat.writeln("@echo off");
      bat.writeln("chcp 65001 >nul");
      bat.writeln("title HeyGram-install-" + stamp);
      bat.writeln('powershell -NoProfile -ExecutionPolicy Bypass -File "' + ps.fsName + '" > "' + logFile + '" 2>&1');
      bat.writeln('echo DONE > "' + doneFile + '"');
      bat.close();
      runHiddenWindows(bat);
    } else {
      var shf = new File(tmp + "/install_" + stamp + ".command");
      shf.open("w");
      shf.writeln("#!/bin/bash");
      shf.writeln('exec > "' + logFile + '" 2>&1');
      shf.writeln('curl -L -o "' + bin + '/yt-dlp" https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos');
      shf.writeln('chmod +x "' + bin + '/yt-dlp"');
      shf.writeln('echo "yt-dlp instalado"');
      shf.writeln('DENO_ARCH="x86_64"; [ "$(uname -m)" = "arm64" ] && DENO_ARCH="aarch64"');
      shf.writeln('curl -L -o "' + bin + '/deno.zip" "https://github.com/denoland/deno/releases/latest/download/deno-${DENO_ARCH}-apple-darwin.zip"');
      shf.writeln('(cd "' + bin + '" && unzip -o deno.zip && rm -f deno.zip && chmod +x deno && echo "deno instalado")');
      shf.writeln('curl -L -o "' + bin + '/gallery-dl" https://github.com/gdl-org/builds/releases/latest/download/gallery-dl_macos');
      shf.writeln('chmod +x "' + bin + '/gallery-dl"');
      shf.writeln('echo "gallery-dl instalado"');
      shf.writeln('echo "Baixando ffmpeg (arquivo maior, pode levar mais tempo)..."');
      shf.writeln('curl -L -o "' + bin + '/ffmpeg.zip" https://evermeet.cx/ffmpeg/getrelease/zip && (cd "' + bin + '" && unzip -o ffmpeg.zip && rm -f ffmpeg.zip && chmod +x ffmpeg && echo "ffmpeg instalado") || echo "Aviso: não foi possível baixar o ffmpeg."');
      shf.writeln('curl -L -o "' + bin + '/ffprobe.zip" https://evermeet.cx/ffmpeg/getrelease/ffprobe/zip && (cd "' + bin + '" && unzip -o ffprobe.zip && rm -f ffprobe.zip && chmod +x ffprobe && echo "ffprobe instalado") || echo "Aviso: não foi possível baixar o ffprobe."');
      shf.writeln('echo DONE > "' + doneFile + '"');
      shf.close();
      shf.execute();
    }

    return "OK|" + logFile + "|" + doneFile;
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

function dg_pollInstall(logFile, doneFile) {
  try {
    var done = new File(doneFile);
    var lastLine = readLastLine(logFile);

    if (done.exists) {
      return "DONE|" + lastLine;
    }
    return "RUNNING|" + lastLine;
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

// ===================== Informações do conteúdo (para o card de preview) =====================
// yt-dlp --dump-json imprime os metadados; o host só devolve o texto bruto,
// o client faz o JSON.parse (JSON.parse não é garantido em ExtendScript).
function dg_startFetchInfo(url, profileStart, profileEnd) {
  try {
    if (!isSupportedVideoUrl(url) && !isInstagramListingUrl(url)) return "ERROR: unsupported url — use uma busca pública, um perfil ou um vídeo compatível.";
    var bin = getBinDir();
    var tmp = getWorkDir();
    var s = sep();
    var ytdlp = bin + s + (isWindows() ? "yt-dlp.exe" : "yt-dlp");
    var ffmpeg = bin + s + (isWindows() ? "ffmpeg.exe" : "ffmpeg");
    var gallery = galleryPath();
    var stamp = "info_" + String(new Date().getTime());
    var urlsFile = tmp + s + stamp + "_url.txt";
    var infoFile = tmp + s + stamp + "_info.txt";
    var logFile = getLogsDir() + s + "analysis_" + stamp + ".txt";
    var doneFile = tmp + s + stamp + "_done.txt";

    var urlF = new File(urlsFile);
    urlF.open("w");
    urlF.write(url);
    urlF.close();

    // Perfis são paginados em pequenos blocos, para não gerar uma extração pesada única.
    var listArgs = "";
    var galleryRange = "";
    if (isInstagramListingUrl(url)) {
      var pageStart = Number(profileStart);
      var pageEnd = Number(profileEnd);
      if (!pageStart || pageStart < 1) pageStart = 1;
      if (!pageEnd || pageEnd < pageStart) pageEnd = pageStart + 11;
      if (pageEnd > pageStart + 49) pageEnd = pageStart + 49;
      // --ignore-errors impede que um post sem vídeo cancele o resto da página.
      listArgs = " --ignore-errors --no-abort-on-error --playlist-start " + Math.floor(pageStart) + " --playlist-end " + Math.floor(pageEnd);
      galleryRange = " --post-range " + Math.floor(pageStart) + "-" + Math.floor(pageEnd);
    }
    // Tenta sem sessão primeiro (conteúdo público); sessão só entra após falha real.
    var runtimeArgs = jsRuntimeArg();
    var anonymousCmd = '"' + ytdlp + '"' + runtimeArgs + ' --dump-json --skip-download --socket-timeout 15' + listArgs + ' --batch-file "' + urlsFile + '"';
    var sessionArgs = cookiesArg();
    var fullCmd = anonymousCmd + sessionArgs;
    var useGallery = isInstagramListingUrl(url);
    var galleryAnonymous = '"' + gallery + '" --config-ignore --no-input --resolve-json --simulate --no-colors --http-timeout 12 --sleep-request 0' + galleryRange + ' -o "extractor.instagram.include=reels" "' + url + '"';
    var galleryFull = galleryAnonymous + sessionArgs;
    // Nas listagens, uma sessão já configurada evita uma tentativa anônima que
    // inevitavelmente cai em fallback e dobra o tempo de cada página.
    var galleryInitial = sessionArgs ? galleryFull : galleryAnonymous;

    var head = new File(logFile);
    head.encoding = "UTF-8";
    head.open("w");
    head.writeln("=== HeyGram " + stamp + " ===");
    head.writeln("URL: " + url);
    head.writeln("yt-dlp existe: " + (new File(ytdlp).exists ? "sim" : "NAO"));
    head.writeln("deno existe: " + (new File(denoPath()).exists ? "sim" : "NAO"));
    head.writeln("gallery-dl existe: " + (new File(gallery).exists ? "sim" : "NAO"));
    head.writeln("runtime JavaScript: " + (runtimeArgs || "NAO CONFIGURADO"));
    head.writeln("Motor selecionado: " + (useGallery ? "gallery-dl (perfil/tema)" : "yt-dlp (vídeo individual)"));
    head.writeln("Estratégia: " + (useGallery && sessionArgs ? "sessão configurada primeiro (busca rápida)." : "anônimo primeiro; sessão apenas em fallback."));
    head.writeln("Fallback de sessão: " + (sessionArgs || "não configurado"));
    head.writeln("Comando anônimo: " + (useGallery ? galleryAnonymous : anonymousCmd));
    head.writeln("=== saida do extrator ===");
    head.close();

    if (isWindows()) {
      var bat = new File(tmp + "\\" + stamp + "_run.bat");
      bat.open("w");
      bat.writeln("@echo off");
      bat.writeln("chcp 65001 >nul");
      bat.writeln("title HeyGram-" + stamp);
      if (useGallery) {
        bat.writeln('"' + gallery + '" --version >> "' + logFile + '" 2>&1');
        bat.writeln('set "HG_SESSION_FALLBACK=0"');
        bat.writeln(galleryInitial + ' > "' + infoFile + '" 2>> "' + logFile + '"');
        bat.writeln('set "HG_EXIT=%ERRORLEVEL%"');
        if (sessionArgs) {
          // gallery-dl pode devolver um JSON de login com código 0. Por isso
          // não usamos apenas errorlevel: também lemos a resposta produzida.
          bat.writeln('if not "%HG_EXIT%"=="0" set "HG_SESSION_FALLBACK=1"');
          bat.writeln('for %%S in ("' + infoFile + '") do if %%~zS LEQ 8 set "HG_SESSION_FALLBACK=1"');
          bat.writeln('findstr /I /C:"AbortExtraction" /C:"accounts/login" "' + infoFile + '" >nul && set "HG_SESSION_FALLBACK=1"');
          bat.writeln('if "%HG_SESSION_FALLBACK%"=="1" (');
          bat.writeln('  echo [HeyGram] fallback de sessao acionado >> "' + logFile + '"');
          bat.writeln('  ' + galleryFull + ' > "' + infoFile + '" 2>> "' + logFile + '"');
          bat.writeln('  set "HG_EXIT=%ERRORLEVEL%"');
          bat.writeln(')');
        }
      } else {
        bat.writeln('"' + ytdlp + '" --version >> "' + logFile + '" 2>&1');
        bat.writeln(anonymousCmd + ' > "' + infoFile + '" 2>> "' + logFile + '"');
        if (sessionArgs) bat.writeln('if errorlevel 1 (' + fullCmd + ' > "' + infoFile + '" 2>> "' + logFile + '")');
      }
      bat.writeln('echo [HeyGram] codigo de saida: ' + (useGallery ? '%HG_EXIT%' : '%errorlevel%') + ' >> "' + logFile + '"');
      bat.writeln('echo DONE > "' + doneFile + '"');
      bat.close();
      runHiddenWindows(bat);
    } else {
      var shr = new File(tmp + "/" + stamp + "_run.command");
      shr.open("w");
      shr.writeln("#!/bin/bash");
      if (useGallery) {
        shr.writeln('"' + gallery + '" --version >> "' + logFile + '" 2>&1');
        shr.writeln(galleryInitial + ' > "' + infoFile + '" 2>> "' + logFile + '"');
        if (sessionArgs) {
          shr.writeln('HG_STATUS=$?');
          shr.writeln('if [ "$HG_STATUS" -ne 0 ] || [ ! -s "' + infoFile + '" ] || [ "$(wc -c < "' + infoFile + '")" -le 8 ] || grep -Eqi "AbortExtraction|accounts/login" "' + infoFile + '"; then');
          shr.writeln('  echo "[HeyGram] fallback de sessao acionado" >> "' + logFile + '"');
          shr.writeln('  ' + galleryFull + ' > "' + infoFile + '" 2>> "' + logFile + '"');
          shr.writeln('fi');
        }
      } else {
        shr.writeln('"' + ytdlp + '" --version >> "' + logFile + '" 2>&1');
        shr.writeln(anonymousCmd + ' > "' + infoFile + '" 2>> "' + logFile + '"');
        if (sessionArgs) shr.writeln('if [ $? -ne 0 ]; then ' + fullCmd + ' > "' + infoFile + '" 2>> "' + logFile + '"; fi');
      }
      shr.writeln('echo "[HeyGram] analise finalizada" >> "' + logFile + '"');
      shr.writeln('echo DONE > "' + doneFile + '"');
      shr.close();
      shr.execute();
    }

    // Painel recebe só o identificador; caminhos ficam no host (evita perder barras invertidas no CEP).
    return "OK|" + stamp;
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

function dg_pollFetchInfo(doneFile, infoFile, logFile) {
  try {
    var done = new File(doneFile);
    if (!done.exists) return "RUNNING|";

    var info = new File(infoFile);
    var content = "";
    if (info.exists) {
      info.encoding = "UTF-8";
      info.open("r");
      content = info.read();
      info.close();
    }
    content = content.replace(/^\s+|\s+$/g, "");

    if (!content) {
      var tail = readLastLines(logFile, 12);
      appendLogFile(logFile, "[HeyGram] RESULTADO: FALHA; nenhum metadado foi retornado.");
      return "FAILED|" + tail;
    }

    // gallery-dl pode devolver [] ao ser redirecionado pro login; converte pra erro de cookies.
    if (/"error"\s*:\s*"AbortExtraction"/i.test(content) && /login/i.test(content)) {
      appendLogFile(logFile, "[HeyGram] RESULTADO: LOGIN_REQUIRED no Instagram.");
      return "FAILED|ERROR: login required para consultar Busca/Perfil. Configure os cookies nas configurações.";
    }
    if (/^\[\s*\]$/.test(content)) {
      var logProbe = new File(logFile);
      var logProbeText = "";
      if (logProbe.exists) {
        logProbe.encoding = "UTF-8";
        logProbe.open("r");
        logProbeText = logProbe.read();
        logProbe.close();
      }
      if (/Motor selecionado:\s*gallery-dl/i.test(logProbeText)) {
        if (/Unable to find .*cookies database|does not support profiles/i.test(logProbeText)) {
          appendLogFile(logFile, "[HeyGram] RESULTADO: FALHA; não foi possível acessar os cookies do navegador configurado.");
          return "FAILED|ERROR: não foi possível acessar os cookies do navegador. Use um arquivo cookies.txt nas configurações.";
        }
        if (!cookiesArg()) {
          appendLogFile(logFile, "[HeyGram] RESULTADO: lista vazia sem sessão; cookies necessários.");
          return "FAILED|ERROR: login required para consultar Busca/Perfil. Configure os cookies nas configurações.";
        }
        appendLogFile(logFile, "[HeyGram] RESULTADO: lista vazia após a sessão; o perfil ou tema não retornou Reels neste lote.");
      }
    }

    // .txt guarda o fluxo humano; .jsonl guarda os metadados exatos.
    try {
      var resultPath = logFile.replace(/\.txt$/i, "_result.jsonl");
      var resultFile = new File(resultPath);
      if (!resultFile.exists) {
        resultFile.encoding = "UTF-8";
        resultFile.open("w");
        resultFile.write(content);
        resultFile.close();
        appendLogFile(logFile, "[HeyGram] RESULTADO: OK; bytes de metadados=" + content.length + "; arquivo=" + resultPath);
      }
    } catch (eResult) {
      appendLogFile(logFile, "[HeyGram] AVISO: não foi possível persistir o JSONL: " + eResult.toString());
    }

    // Devolve o conteúdo bruto. O client faz o JSON.parse.
    return "DONE|" + content;
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

function dg_pollFetchInfoByStamp(stamp) {
  var tmp = getWorkDir();
  var s = sep();
  return dg_pollFetchInfo(
    tmp + s + stamp + "_done.txt",
    tmp + s + stamp + "_info.txt",
    getLogsDir() + s + "analysis_" + stamp + ".txt"
  );
}

// ===================== Busca de perfis =====================
// Usa a busca topsearch do Instagram pra devolver perfis compatíveis com a arroba digitada.
function dg_startProfileSearch(query) {
  try {
    var value = String(query || "").replace(/^\s+|\s+$/g, "").replace(/^@/, "");
    if (value.length < 2) return "ERROR: digite pelo menos dois caracteres para buscar perfis.";
    var cookieFile = String(readCookiesFileSetting() || "");
    var deno = denoPath();
    if (!new File(deno).exists) return "ERROR: o componente Deno não foi instalado.";

    var tmp = getWorkDir();
    var s = sep();
    var stamp = "profile_search_" + String(new Date().getTime());
    var queryFile = tmp + s + stamp + "_query.txt";
    var scriptFile = tmp + s + stamp + "_run.js";
    var resultFile = tmp + s + stamp + "_result.json";
    var doneFile = tmp + s + stamp + "_done.txt";
    var logFile = getLogsDir() + s + stamp + ".txt";
    // O CEP falha ao carregar diretamente muitas URLs CDN do Instagram. As
    // fotos são baixadas pelo Deno para o cache local e devolvidas por file://.
    var avatarFolder = new Folder(tmp + s + "profile_avatars");
    if (!avatarFolder.exists) avatarFolder.create();

    var qf = new File(queryFile);
    qf.encoding = "UTF-8";
    qf.open("w"); qf.write(value); qf.close();

    var script = new File(scriptFile);
    script.encoding = "UTF-8";
    script.open("w");
    script.writeln('const [queryPath, cookiePath, avatarDir] = Deno.args;');
    script.writeln('const query = (await Deno.readTextFile(queryPath)).trim();');
    script.writeln('let cookies = [];');
    script.writeln('if (cookiePath) {');
    script.writeln('  const source = await Deno.readTextFile(cookiePath);');
    script.writeln('  for (let line of source.split(/\\r?\\n/)) {');
    script.writeln('    if (line.indexOf("#HttpOnly_") === 0) line = line.slice(10);');
    script.writeln('    if (!line || line[0] === "#") continue;');
    script.writeln('    const p = line.split("\\t");');
    script.writeln('    if (p.length >= 7 && /(^|\\.)instagram\\.com$/i.test(p[0])) cookies.push(p[5] + "=" + p[6]);');
    script.writeln('  }');
    script.writeln('}');
    script.writeln('const headers = { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36", "X-IG-App-ID": "936619743392459", "X-Requested-With": "XMLHttpRequest", "Accept": "*/*" };');
    script.writeln('if (cookies.length) headers.Cookie = cookies.join("; ");');
    // Timeout curto em cada fetch: sem isso, uma resposta que trava (rede
    // instavel/bloqueio silencioso) prende o processo Deno rodando escondido
    // e o resultFile so' aparece muito depois -- do lado do painel isso
    // parece uma busca "infinita" ate o limite de 30s do cliente estourar.
    script.writeln('try {');
    script.writeln('  const response = await fetch("https://www.instagram.com/web/search/topsearch/?query=" + encodeURIComponent(query), { headers, signal: AbortSignal.timeout(9000) });');
    script.writeln('  if (response.status === 401 || response.status === 403) throw new Error("Os cookies configurados foram recusados pelo Instagram (sessão expirada ou inválida). Gere um novo cookies.txt com a extensão HeyGram Cookies.");');
    script.writeln('  if (!response.ok) throw new Error("Instagram respondeu HTTP " + response.status);');
    script.writeln('  const data = await response.json();');
    script.writeln('  await Deno.mkdir(avatarDir, { recursive: true });');
    script.writeln('  const rawUsers = (data.users || []).map((item) => item.user || item).filter((user) => user && user.username).slice(0, 12);');
    script.writeln('  const users = await Promise.all(rawUsers.map(async (user, index) => { let local_avatar = ""; try { if (user.profile_pic_url) { const image = await fetch(user.profile_pic_url, { headers, signal: AbortSignal.timeout(6000) }); if (image.ok) { const safe = String(user.username).replace(/[^a-z0-9_-]/gi, "_"); const avatarPath = avatarDir + "/" + safe + "_" + index + ".jpg"; await Deno.writeFile(avatarPath, new Uint8Array(await image.arrayBuffer())); local_avatar = "file:///" + avatarPath.replace(/\\\\/g, "/"); } } } catch (_) {} return { username: user.username, full_name: user.full_name || "", profile_pic_url: user.profile_pic_url || "", local_avatar, is_private: !!user.is_private, is_verified: !!user.is_verified, follower_count: user.follower_count || 0 }; }));');
    script.writeln('  console.log(JSON.stringify({ users }));');
    script.writeln('} catch (error) { console.log(JSON.stringify({ users: [], error: String(error && error.message || error) })); }');
    script.close();

    var head = new File(logFile);
    head.encoding = "UTF-8";
    head.open("w");
    head.writeln("=== HeyGram " + stamp + " ===");
    head.writeln("Consulta: busca de perfis");
    head.writeln("Termo: " + value);
    head.writeln("Deno existe: sim");
    head.writeln("Cookies: " + (cookieFile ? "arquivo configurado" : "não configurado; tentativa pública"));
    head.writeln("=== saida da busca ===");
    head.close();

    if (isWindows()) {
      var bat = new File(tmp + s + stamp + "_run.bat");
      bat.open("w");
      bat.writeln("@echo off");
      bat.writeln("chcp 65001 >nul");
      bat.writeln('"' + deno + '" run --quiet --allow-read="' + queryFile + (cookieFile ? ',' + cookieFile : '') + '" --allow-write="' + avatarFolder.fsName + '" --allow-net "' + scriptFile + '" "' + queryFile + '" "' + cookieFile + '" "' + avatarFolder.fsName + '" > "' + resultFile + '" 2>> "' + logFile + '"');
      bat.writeln('echo [HeyGram] codigo de saida: %errorlevel% >> "' + logFile + '"');
      bat.writeln('echo DONE > "' + doneFile + '"');
      bat.close();
      runHiddenWindows(bat);
    } else {
      var sh = new File(tmp + s + stamp + "_run.command");
      sh.open("w");
      sh.writeln("#!/bin/bash");
      sh.writeln('"' + deno + '" run --quiet --allow-read="' + queryFile + (cookieFile ? ',' + cookieFile : '') + '" --allow-write="' + avatarFolder.fsName + '" --allow-net "' + scriptFile + '" "' + queryFile + '" "' + cookieFile + '" "' + avatarFolder.fsName + '" > "' + resultFile + '" 2>> "' + logFile + '"');
      sh.writeln('echo "[HeyGram] analise finalizada" >> "' + logFile + '"');
      sh.writeln('echo DONE > "' + doneFile + '"');
      sh.close(); sh.execute();
    }
    return "OK|" + stamp;
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

function dg_pollProfileSearchByStamp(stamp) {
  var tmp = getWorkDir();
  var s = sep();
  return dg_pollFetchInfo(
    tmp + s + stamp + "_done.txt",
    tmp + s + stamp + "_result.json",
    getLogsDir() + s + stamp + ".txt"
  );
}

// Busca bio e contadores do perfil (a busca inicial só traz itens compactos).
function dg_startProfileDetails(username) {
  try {
    var value = String(username || "").replace(/^@/, "").replace(/[^A-Za-z0-9._]/g, "");
    if (!value) return "ERROR: perfil inválido.";
    var cookieFile = readCookiesFileSetting();
    if (!cookieFile) return "ERROR: configure um arquivo cookies.txt para abrir os dados do perfil.";
    var deno = denoPath();
    if (!new File(deno).exists) return "ERROR: o componente Deno não foi instalado.";
    var tmp = getWorkDir(), s = sep(), stamp = "profile_details_" + String(new Date().getTime());
    var queryFile = tmp + s + stamp + "_query.txt", scriptFile = tmp + s + stamp + "_run.js";
    var resultFile = tmp + s + stamp + "_info.txt", doneFile = tmp + s + stamp + "_done.txt";
    var logFile = getLogsDir() + s + stamp + ".txt";
    var qf = new File(queryFile); qf.encoding = "UTF-8"; qf.open("w"); qf.write(value); qf.close();
    var script = new File(scriptFile); script.encoding = "UTF-8"; script.open("w");
    script.writeln('const [queryPath, cookiePath] = Deno.args;');
    script.writeln('const username = (await Deno.readTextFile(queryPath)).trim();');
    script.writeln('const source = await Deno.readTextFile(cookiePath); const cookies = [];');
    script.writeln('for (let line of source.split(/\\r?\\n/)) { if (line.indexOf("#HttpOnly_") === 0) line = line.slice(10); if (!line || line[0] === "#") continue; const p = line.split("\\t"); if (p.length >= 7 && /(^|\\.)instagram\\.com$/i.test(p[0])) cookies.push(p[5] + "=" + p[6]); }');
    script.writeln('if (!cookies.length) throw new Error("cookies.txt não possui cookies do Instagram");');
    script.writeln('const csrf = (cookies.find((value) => value.indexOf("csrftoken=") === 0) || "").split("=").slice(1).join("=");');
    script.writeln('const headers = { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36", "X-IG-App-ID": "936619743392459", "X-Requested-With": "XMLHttpRequest", "Accept": "*/*", "Referer": "https://www.instagram.com/", "X-CSRFToken": csrf, "Cookie": cookies.join("; ") };');
    // Timeout curto (AbortSignal) evita a chamada Deno travar presa no TCP.
    script.writeln('async function safeFetch(url) { try { return await fetch(url, { headers, signal: AbortSignal.timeout(7000) }); } catch (_) { return null; } }');
    script.writeln('async function safeJson(response) { if (!response || !response.ok) return {}; const text = await response.text(); try { return text ? JSON.parse(text) : {}; } catch (_) { return {}; } }');
    script.writeln('const urls = ["https://www.instagram.com/api/v1/users/web_profile_info/?username=" + encodeURIComponent(username), "https://www.instagram.com/" + encodeURIComponent(username) + "/?__a=1&__d=dis"]; let user = {};');
    script.writeln('for (const url of urls) { const payload = await safeJson(await safeFetch(url)); user = (payload.data || {}).user || (payload.graphql || {}).user || payload.user || {}; if (user.username) break; }');
    script.writeln('if (!user.username) { console.log(JSON.stringify({ error: "Não foi possível carregar os detalhes deste perfil agora." })); } else { console.log(JSON.stringify({ username: user.username || username, full_name: user.full_name || "", biography: user.biography || "", profile_pic_url: user.profile_pic_url_hd || user.profile_pic_url || ((user.hd_profile_pic_url_info || {}).url || ""), posts: ((user.edge_owner_to_timeline_media || {}).count || user.media_count || 0), followers: ((user.edge_followed_by || {}).count || user.follower_count || 0), following: ((user.edge_follow || {}).count || user.following_count || 0) })); }');
    script.close();
    var log = new File(logFile); log.encoding = "UTF-8"; log.open("w"); log.writeln("=== HeyGram " + stamp + " ==="); log.writeln("Consulta: detalhes de perfil"); log.writeln("Perfil: " + value); log.close();
    if (isWindows()) { var bat = new File(tmp + s + stamp + "_run.bat"); bat.open("w"); bat.writeln("@echo off"); bat.writeln("chcp 65001 >nul"); bat.writeln('"' + deno + '" run --quiet --allow-read="' + queryFile + ',' + cookieFile + '" --allow-net=www.instagram.com,instagram.com "' + scriptFile + '" "' + queryFile + '" "' + cookieFile + '" > "' + resultFile + '" 2>> "' + logFile + '"'); bat.writeln('echo [HeyGram] codigo de saida: %errorlevel% >> "' + logFile + '"'); bat.writeln('echo DONE > "' + doneFile + '"'); bat.close(); runHiddenWindows(bat); }
    else { var sh = new File(tmp + s + stamp + "_run.command"); sh.open("w"); sh.writeln("#!/bin/bash"); sh.writeln('"' + deno + '" run --quiet --allow-read="' + queryFile + ',' + cookieFile + '" --allow-net=www.instagram.com,instagram.com "' + scriptFile + '" "' + queryFile + '" "' + cookieFile + '" > "' + resultFile + '" 2>> "' + logFile + '"'); sh.writeln('echo DONE > "' + doneFile + '"'); sh.close(); sh.execute(); }
    return "OK|" + stamp;
  } catch (e) { return "ERROR: " + e.toString(); }
}
function dg_pollProfileDetailsByStamp(stamp) {
  var tmp = getWorkDir(), s = sep();
  return dg_pollFetchInfo(tmp + s + stamp + "_done.txt", tmp + s + stamp + "_info.txt", getLogsDir() + s + stamp + ".txt");
}

// Busca Reels por tema; mantém só itens identificados como clips/Reels (nunca foto ou carrossel).
function dg_startReelSearch(query) {
  try {
    var value = String(query || "").replace(/^\s+|\s+$/g, "").replace(/^#/, "");
    if (!value) return "ERROR: informe um tema para buscar.";
    var cookieFile = readCookiesFileSetting();
    if (!cookieFile) return "ERROR: configure um arquivo cookies.txt para buscar Reels.";
    var deno = denoPath();
    if (!new File(deno).exists) return "ERROR: o componente Deno não foi instalado.";
    var tmp = getWorkDir(), s = sep(), stamp = "reel_search_" + String(new Date().getTime());
    var queryFile = tmp + s + stamp + "_query.txt", scriptFile = tmp + s + stamp + "_run.js";
    var resultFile = tmp + s + stamp + "_result.json", doneFile = tmp + s + stamp + "_done.txt";
    var logFile = getLogsDir() + s + stamp + ".txt";
    var qf = new File(queryFile); qf.encoding = "UTF-8"; qf.open("w"); qf.write(value); qf.close();
    var script = new File(scriptFile); script.encoding = "UTF-8"; script.open("w");
    script.writeln('const [queryPath, cookiePath] = Deno.args;');
    script.writeln('const query = (await Deno.readTextFile(queryPath)).trim().replace(/^#/, "");');
    script.writeln('const source = await Deno.readTextFile(cookiePath); const cookies = [];');
    script.writeln('for (let line of source.split(/\\r?\\n/)) { if (line.indexOf("#HttpOnly_") === 0) line = line.slice(10); if (!line || line[0] === "#") continue; const p = line.split("\\t"); if (p.length >= 7 && /(^|\\.)instagram\\.com$/i.test(p[0])) cookies.push(p[5] + "=" + p[6]); }');
    script.writeln('if (!cookies.length) throw new Error("cookies.txt não possui cookies do Instagram");');
    script.writeln('const headers = { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36", "X-IG-App-ID": "936619743392459", "X-Requested-With": "XMLHttpRequest", "Accept": "application/json", "Cookie": cookies.join("; ") };');
    script.writeln('const response = await fetch("https://www.instagram.com/api/v1/tags/web_info/?tag_name=" + encodeURIComponent(query), { headers });');
    script.writeln('const text = await response.text(); if (!response.ok) throw new Error("Instagram respondeu HTTP " + response.status); let payload; try { payload = JSON.parse(text); } catch (_) { throw new Error("Instagram não devolveu uma resposta de busca válida"); }');
    script.writeln('const out = [], seen = new Set();');
    script.writeln('function walk(value) { if (!value) return; if (Array.isArray(value)) { value.forEach(walk); return; } if (typeof value !== "object") return; const code = value.code || value.shortcode || ""; const product = String(value.product_type || "").toLowerCase(); const isCarousel = !!value.carousel_media || !!value.carousel_media_count || String(value.media_type_name || value.typename || "").toLowerCase().includes("sidecar"); const video = value.video_versions || value.video_url || value.video_duration || value.media_type === 2; if (code && video && !isCarousel && (/clips|reel/.test(product) || !!value.video_versions)) { if (!seen.has(code)) { seen.add(code); const image = (((value.image_versions2 || {}).candidates || [])[0] || {}).url || value.thumbnail_url || ""; const user = value.user || {}; out.push({ webpage_url: "https://www.instagram.com/reel/" + code + "/", shortcode: code, product_type: "clips", extension: "mp4", duration: value.video_duration || 0, thumbnail: image, description: value.caption && value.caption.text || value.caption_text || "", username: user.username || "", full_name: user.full_name || "" }); } } for (const key of Object.keys(value)) { const child = value[key]; if (child && typeof child === "object") walk(child); } }');
    script.writeln('walk(payload); console.log(JSON.stringify({ reels: out.slice(0, 60) }));');
    script.close();
    var log = new File(logFile); log.encoding = "UTF-8"; log.open("w"); log.writeln("=== HeyGram " + stamp + " ==="); log.writeln("Consulta: busca de Reels"); log.writeln("Termo: " + value); log.close();
    if (isWindows()) { var bat = new File(tmp + s + stamp + "_run.bat"); bat.open("w"); bat.writeln("@echo off"); bat.writeln("chcp 65001 >nul"); bat.writeln('"' + deno + '" run --quiet --allow-read="' + queryFile + ',' + cookieFile + '" --allow-net=www.instagram.com,instagram.com "' + scriptFile + '" "' + queryFile + '" "' + cookieFile + '" > "' + resultFile + '" 2>> "' + logFile + '"'); bat.writeln('echo [HeyGram] codigo de saida: %errorlevel% >> "' + logFile + '"'); bat.writeln('echo DONE > "' + doneFile + '"'); bat.close(); runHiddenWindows(bat); }
    else { var sh = new File(tmp + s + stamp + "_run.command"); sh.open("w"); sh.writeln("#!/bin/bash"); sh.writeln('"' + deno + '" run --quiet --allow-read="' + queryFile + ',' + cookieFile + '" --allow-net=www.instagram.com,instagram.com "' + scriptFile + '" "' + queryFile + '" "' + cookieFile + '" > "' + resultFile + '" 2>> "' + logFile + '"'); sh.writeln('echo DONE > "' + doneFile + '"'); sh.close(); sh.execute(); }
    return "OK|" + stamp;
  } catch (e) { return "ERROR: " + e.toString(); }
}
function dg_pollReelSearchByStamp(stamp) {
  var tmp = getWorkDir(), s = sep();
  return dg_pollFetchInfo(tmp + s + stamp + "_done.txt", tmp + s + stamp + "_result.json", getLogsDir() + s + stamp + ".txt");
}

// CEF falha silenciosamente com alguns MP4s via file://; o player sempre recebe
// HTTP local (127.0.0.1) servido pelo Deno portátil. Cada sessão recebe uma
// rota não previsível e o servidor não expõe CORS aberto.
function dg_writePlayerServer(scriptPath) {
  var script = new File(scriptPath);
  script.encoding = "UTF-8";
  script.open("w");
  script.writeln('const [file, portText, token] = Deno.args; const port = Number(portText);');
  script.writeln('const baseHeaders = { "Content-Type": "video/mp4", "Accept-Ranges": "bytes", "Cache-Control": "no-store" };');
  script.writeln('Deno.serve({ hostname: "127.0.0.1", port }, async (request) => {');
  script.writeln('  const pathname = new URL(request.url).pathname;');
  script.writeln('  if (pathname === "/health/" + token) return new Response("ok", { status: 200, headers: { "Cache-Control": "no-store" } });');
  script.writeln('  if (pathname !== "/preview/" + token + ".mp4") return new Response("Not found", { status: 404 });');
  script.writeln('  try {');
  script.writeln('    const size = (await Deno.stat(file)).size, range = request.headers.get("range"), headers = { ...baseHeaders, "Content-Length": String(size) };');
  script.writeln('    if (request.method === "HEAD") return new Response(null, { status: 200, headers });');
  script.writeln('    const match = range && /bytes=(\\d*)-(\\d*)/.exec(range);');
  script.writeln('    if (match) { const start = Math.min(Number(match[1] || 0), Math.max(0, size - 1)); const end = Math.min(Number(match[2] || size - 1), size - 1); const body = (await Deno.readFile(file)).slice(start, end + 1); return new Response(body, { status: 206, headers: { ...baseHeaders, "Content-Range": "bytes " + start + "-" + end + "/" + size, "Content-Length": String(body.length) } }); }');
  script.writeln('    return new Response(await Deno.readFile(file), { status: 200, headers });');
  script.writeln('  } catch (error) { return new Response("Not found", { status: 404 }); }');
  script.writeln('});');
  script.writeln('setTimeout(() => Deno.exit(0), 300000);');
  script.close();
}

function dg_playerServerPort(stamp) {
  var n = Number(String(stamp || "").replace(/[^0-9]/g, "").slice(-4)) || 0;
  return 43000 + (n % 2000);
}

function dg_playerServerToken(stamp) {
  var random = Math.floor(Math.random() * 0x7fffffff).toString(36);
  return (String(stamp || "").replace(/[^A-Za-z0-9]/g, "") + random + String(new Date().getTime())).slice(-38);
}

// Prévia local temporária: não vai pra biblioteca, é removida na limpeza normal do cache.
function dg_startPreview(url) {
  try {
    if (!isSupportedVideoUrl(url)) return "ERROR: endereço de vídeo inválido.";
    var bin = getBinDir(), tmp = getWorkDir(), s = sep(), stamp = "preview_" + String(new Date().getTime());
    var ytdlp = bin + s + (isWindows() ? "yt-dlp.exe" : "yt-dlp");
    var ffmpeg = bin + s + (isWindows() ? "ffmpeg.exe" : "ffmpeg");
    if (!new File(ytdlp).exists) return "ERROR: o componente de download não foi instalado.";
    var urlFile = tmp + s + stamp + "_url.txt", resultFile = tmp + s + stamp + "_result.txt", doneFile = tmp + s + stamp + "_done.txt", logFile = getLogsDir() + s + stamp + ".txt";
    var sourceBase = tmp + s + stamp + "_source", playerServer = tmp + s + stamp + "_player_server.js", playerPort = dg_playerServerPort(stamp), playerToken = dg_playerServerToken(stamp), deno = denoPath();
    if (!new File(deno).exists) return "ERROR: o componente Deno não foi instalado.";
    dg_writePlayerServer(playerServer);
    var f = new File(urlFile); f.open("w"); f.write(url); f.close();
    var log = new File(logFile); log.open("w"); log.writeln("=== HeyGram " + stamp + " ==="); log.writeln("Consulta: prévia local do player"); log.writeln("URL: " + url); log.close();
    // Em .bat, %% é o caractere literal % — necessário pro template -o do yt-dlp.
    var command = '"' + ytdlp + '"' + jsRuntimeArg() + ' --no-playlist --merge-output-format mp4 --ffmpeg-location "' + bin + '" -f "bv*[vcodec^=avc]+ba[acodec^=mp4a]/b[vcodec^=avc]/b" -o "' + sourceBase + '.%%(ext)s" --batch-file "' + urlFile + '"' + cookiesArg();
    if (isWindows()) {
      var bat = new File(tmp + s + stamp + "_run.bat");
      bat.open("w");
      bat.writeln("@echo off");
      bat.writeln("chcp 65001 >nul");
      bat.writeln(command + ' >> "' + logFile + '" 2>&1');
      // A prévia precisa ser H.264/AAC: o CEF de algumas versões do Premiere
      // abre VP9 como um quadro preto, mesmo quando o arquivo é válido.
      bat.writeln('set "DGPREVIEW="');
      bat.writeln('for %%F in ("' + sourceBase + '.mp4") do if exist "%%~fF" set "DGPREVIEW=%%~fF"');
      bat.writeln('if defined DGPREVIEW if exist "' + ffmpeg + '" "' + ffmpeg + '" -y -i "%DGPREVIEW%" -map 0:v:0 -map "0:a:0?" -c:v libx264 -preset veryfast -crf 21 -pix_fmt yuv420p -c:a aac -b:a 160k -movflags +faststart "' + sourceBase + '_cep.mp4" >> "' + logFile + '" 2>&1');
       bat.writeln('if exist "' + sourceBase + '_cep.mp4" start "" /b "' + deno + '" run --quiet --allow-read="' + sourceBase + '_cep.mp4" --allow-net=127.0.0.1 "' + playerServer + '" "' + sourceBase + '_cep.mp4" "' + playerPort + '" "' + playerToken + '" >> "' + logFile + '" 2>&1');
      bat.writeln('if exist "' + sourceBase + '_cep.mp4" timeout /t 1 /nobreak >nul');
       bat.writeln('if exist "' + sourceBase + '_cep.mp4" echo http://127.0.0.1:' + playerPort + '/preview/' + playerToken + '.mp4 > "' + resultFile + '"');
      bat.writeln('echo DONE > "' + doneFile + '"');
      bat.close();
      runHiddenWindows(bat);
    }
    else { var sh = new File(tmp + s + stamp + "_run.command"); sh.open("w"); sh.writeln("#!/bin/bash"); sh.writeln(command + ' >> "' + logFile + '" 2>&1'); sh.writeln('ls "' + sourceBase + '".* 2>/dev/null | head -n 1 > "' + resultFile + '"'); sh.writeln('echo DONE > "' + doneFile + '"'); sh.close(); sh.execute(); }
    return "OK|" + stamp;
  } catch (e) { return "ERROR: " + e.toString(); }
}
function dg_pollPreviewByStamp(stamp) {
  try { var tmp = getWorkDir(), s = sep(), done = new File(tmp + s + stamp + "_done.txt"), result = new File(tmp + s + stamp + "_result.txt"); if (!done.exists) return "RUNNING|"; if (!result.exists) return "ERROR: não foi possível preparar a prévia."; result.open("r"); var path = result.read().replace(/^\s+|\s+$/g, ""); result.close(); return path ? "DONE|" + path : "ERROR: não foi possível preparar a prévia."; } catch (e) { return "ERROR: " + e.toString(); }
}

// Mesmo servidor local usado pra um MP4 já salvo na Biblioteca.
function dg_startLocalPlayerFile(mediaPath) {
  try {
    var media = String(mediaPath || "");
    if (!media || !(new File(media)).exists) return "ERROR: O vídeo local não foi encontrado.";
    var tmp = getWorkDir(), s = sep(), stamp = "local_player_" + String(new Date().getTime()), deno = denoPath(), port = dg_playerServerPort(stamp), token = dg_playerServerToken(stamp);
    if (!new File(deno).exists) return "ERROR: o componente Deno não foi instalado.";
    var serverFile = tmp + s + stamp + "_server.js", resultFile = tmp + s + stamp + "_result.txt", doneFile = tmp + s + stamp + "_done.txt", logFile = getLogsDir() + s + stamp + ".txt";
    dg_writePlayerServer(serverFile);
    if (isWindows()) { var bat = new File(tmp + s + stamp + "_run.bat"); bat.open("w"); bat.writeln("@echo off"); bat.writeln('start "" /b "' + deno + '" run --quiet --allow-read="' + media + '" --allow-net=127.0.0.1 "' + serverFile + '" "' + media + '" "' + port + '" "' + token + '" >> "' + logFile + '" 2>&1'); bat.writeln('timeout /t 1 /nobreak >nul'); bat.writeln('echo http://127.0.0.1:' + port + '/preview/' + token + '.mp4 > "' + resultFile + '"'); bat.writeln('echo DONE > "' + doneFile + '"'); bat.close(); runHiddenWindows(bat); }
    else { return "ERROR: servidor local do player ainda não foi preparado neste sistema."; }
    return "OK|" + stamp;
  } catch (e) { return "ERROR: " + e.toString(); }
}
function dg_pollLocalPlayerFile(stamp) {
  var tmp = getWorkDir(), s = sep();
  return dg_pollFetchInfo(tmp + s + stamp + "_done.txt", tmp + s + stamp + "_result.txt", getLogsDir() + s + stamp + ".txt");
}

// ===================== Download =====================
// Cada download vai para <pasta-base>/Reels/<@perfil>_<timestamp>/, evitando colisão de nomes.
function dg_startDownload(url, wantThumbnail, wantCaption, profileName, audioOnly, mediaTitle, mediaThumbnail, mediaDuration) {
  try {
    if (!isSupportedVideoUrl(url)) return "ERROR: unsupported url — use um link de Reel do Instagram.";
    var bin = getBinDir();
    var tmp = getWorkDir();
    var s = sep();
    var ytdlp = bin + s + (isWindows() ? "yt-dlp.exe" : "yt-dlp");
    var stamp = String(new Date().getTime());
    var safeProfile = asciiFolderName(String(profileName || "instagram").replace(/^@/, "")) || "instagram";
    var downloadFolder = new Folder(getMediaDir() + s + safeProfile + "_" + stamp);
    if (!downloadFolder.exists) downloadFolder.create();

    // Manifesto com título/duração/thumbnail, pra biblioteca sobreviver a reinício do painel.
    var libraryMeta = new File(downloadFolder.fsName + s + ".heygram.json");
    libraryMeta.encoding = "UTF-8";
    libraryMeta.open("w");
    libraryMeta.write('{"title":' + dg_jsonQuote(mediaTitle || "Reel baixado") + ',"thumbnail":' + dg_jsonQuote(mediaThumbnail || "") + ',"duration":' + dg_jsonQuote(mediaDuration || "—") + ',"url":' + dg_jsonQuote(url || "") + ',"handle":' + dg_jsonQuote(profileName || "") + '}');
    libraryMeta.close();

    // ATENÇÃO: não usar %(playlist_index)03d — um Reel avulso não é playlist,
    // o índice vem vazio e o arquivo sai "media_NA.mp4". %(autonumber)s sempre existe.
    var outTemplate = downloadFolder.fsName + s + "media_%(autonumber)03d.%(ext)s";
    var logFile = getLogsDir() + s + "download_" + stamp + ".txt";
    var doneFile = tmp + s + "done_" + stamp + ".txt";
    var urlsFile = tmp + s + "urls_" + stamp + ".txt";

    // URL num arquivo à parte: evita que %, & etc. sejam mal interpretados pelo shell.
    var urlF = new File(urlsFile);
    urlF.open("w");
    urlF.write(url);
    urlF.close();

    // Premiere não decodifica VP9/AV1 de forma confiável: baixa a melhor qualidade
    // sem limitar o codec e normaliza pra H.264 depois, se necessário.
    var args = audioOnly ? '-f "ba/b"' : '--merge-output-format mp4 -f "bv*+ba/b"';
    args += ' --ffmpeg-location "' + bin + '" -o "' + outTemplate + '" --batch-file "' + urlsFile + '"';
    if (wantCaption) args += ' --write-description';

    if (wantThumbnail) {
      // --convert-thumbnails jpg: Instagram entrega webp, o Premiere quer jpg.
      args += ' --write-thumbnail --convert-thumbnails jpg';
    }

    var runtimeArgs = jsRuntimeArg();
    var anonymousCmd = '"' + ytdlp + '"' + runtimeArgs + ' ' + args;
    var sessionArgs = cookiesArg();
    var fullCmd = anonymousCmd + sessionArgs;
    var ffmpegPath = bin + s + (isWindows() ? "ffmpeg.exe" : "ffmpeg");
    var ffprobePath = bin + s + (isWindows() ? "ffprobe.exe" : "ffprobe");

    var head = new File(logFile);
    head.encoding = "UTF-8";
    head.open("w");
    head.writeln("=== HeyGram " + stamp + " ===");
    head.writeln("URL: " + url);
    head.writeln("Pasta de midia: " + getMediaDir());
    head.writeln("Pasta deste download: " + downloadFolder.fsName);
    head.writeln("Config de pasta: " + (readTempFolderSetting() || "(padrao)"));
    head.writeln("yt-dlp existe: " + (new File(ytdlp).exists ? "sim" : "NAO"));
    head.writeln("ffmpeg existe: " + (new File(ffmpegPath).exists ? "sim" : "NAO"));
    head.writeln("ffprobe existe: " + (new File(ffprobePath).exists ? "sim" : "NAO"));
    head.writeln("deno existe: " + (new File(denoPath()).exists ? "sim" : "NAO"));
    head.writeln("runtime JavaScript: " + (runtimeArgs || "NAO CONFIGURADO"));
    head.writeln("Estratégia: anônimo primeiro; sessão apenas em fallback.");
    head.writeln("Fallback de sessão: " + (sessionArgs || "não configurado"));
    head.writeln("Comando anônimo: " + anonymousCmd);
    head.writeln("=== saida do yt-dlp ===");
    head.close();

    if (isWindows()) {
      // Escapa % como %% para o CMD não tentar expandir %(ext)s como variável
      var cmdLine = anonymousCmd.replace(/%/g, "%%");
      var sessionCmdLine = fullCmd.replace(/%/g, "%%");
      var bat = new File(tmp + "\\run_" + stamp + ".bat");
      bat.open("w");
      bat.writeln("@echo off");
      bat.writeln("chcp 65001 >nul");
      bat.writeln("title HeyGram-" + stamp);
      bat.writeln('"' + ytdlp + '" --version >> "' + logFile + '" 2>&1');
      bat.writeln(cmdLine + ' >> "' + logFile + '" 2>&1');
      if (sessionArgs) bat.writeln('if errorlevel 1 (' + sessionCmdLine + ' >> "' + logFile + '" 2>&1)');
      // Reconverte imagens pra PNG limpo (Premiere às vezes recusa jpg/webp com
      // perfis de cor incomuns). dir /b + findstr em vez de "for %%F in (mascara)":
      // a lista é congelada antes do loop, senão PNGs recém-criados seriam reprocessados.
      var df = downloadFolder.fsName;
      bat.writeln('if exist "' + ffmpegPath + '" (');
      bat.writeln('  for /f "delims=" %%F in (\'dir /b /a-d "' + df + '\\media_*.jpg" "' + df + '\\media_*.jpeg" "' + df + '\\media_*.png" "' + df + '\\media_*.webp" 2^>nul ^| findstr /v /i "_clean"\') do (');
      bat.writeln('    "' + ffmpegPath + '" -y -i "' + df + '\\%%F" -frames:v 1 -update 1 "' + df + '\\%%~nF_clean.png" >> "' + logFile + '" 2>&1');
      bat.writeln('  )');
      bat.writeln(')');

      // Rede de segurança do codec: um Reel pode só existir em VP9/AV1, e o
      // Premiere importa mas só enxerga o áudio. Checa com ffprobe e recodifica
      // se não for H.264. Busca o MP4 real (yt-dlp pode sufixar o nome no merge,
      // ex. media_001.fdash-....mp4) pra não deixar VP9 passar sem verificação.
      bat.writeln('set "DGDIR=' + df + '"');
      bat.writeln('setlocal EnableDelayedExpansion');
      // Cada item de um carrossel é validado e normalizado individualmente.
      bat.writeln('for /f "delims=" %%V in (\'dir /b /a-d "%DGDIR%\\media_*.mp4" 2^>nul ^| findstr /v /i "_h264"\') do (');
      bat.writeln('  set "DGVID=%DGDIR%\\%%V"');
      bat.writeln('  set "DGCODEC="');
      bat.writeln('  "' + ffprobePath + '" -v error -select_streams v:0 -show_entries stream=codec_name -of default=nw=1:nk=1 "!DGVID!" > "%DGDIR%\\_codec.txt" 2>>"' + logFile + '"');
      bat.writeln('  if exist "%DGDIR%\\_codec.txt" set /p DGCODEC=<"%DGDIR%\\_codec.txt"');
      bat.writeln('  if exist "%DGDIR%\\_codec.txt" del /q "%DGDIR%\\_codec.txt"');
      bat.writeln('  echo [HeyGram] %%V codec: !DGCODEC! >> "' + logFile + '"');
      bat.writeln('  if not "!DGCODEC!"=="" if /i not "!DGCODEC!"=="h264" (');
      bat.writeln('    echo [HeyGram] %%V recodificando para H.264... >> "' + logFile + '"');
      bat.writeln('    "' + ffmpegPath + '" -y -i "!DGVID!" -map 0:v:0 -map "0:a:0?" -c:v libx264 -preset veryfast -crf 18 -pix_fmt yuv420p -c:a aac -b:a 192k -movflags +faststart "%DGDIR%\\%%~nV_h264.mp4" >> "' + logFile + '" 2>&1');
      bat.writeln('    if exist "%DGDIR%\\%%~nV_h264.mp4" del /q "!DGVID!"');
      bat.writeln('    if exist "%DGDIR%\\%%~nV_h264.mp4" ren "%DGDIR%\\%%~nV_h264.mp4" "%%V"');
      bat.writeln('  )');
      bat.writeln(')');
      bat.writeln('for /f "delims=" %%V in (\'dir /b /a-d "%DGDIR%\\media_*.mp4" 2^>nul\') do "' + ffprobePath + '" -v error -show_entries stream=index,codec_type,codec_name,width,height,sample_rate,channels -of default=nw=1 "%DGDIR%\\%%V" >> "' + logFile + '" 2>&1');

      // Renomeia .description para .txt: Windows não associa .description a nada.
      bat.writeln('for /f "delims=" %%F in (\'dir /b /a-d "' + df + '\\media_*.description" 2^>nul\') do ren "' + df + '\\%%F" "%%~nF.txt"');

      bat.writeln('echo DONE > "' + doneFile + '"');
      bat.close();
      runHiddenWindows(bat);
    } else {
      var shr = new File(tmp + "/run_" + stamp + ".command");
      shr.open("w");
      shr.writeln("#!/bin/bash");
      shr.writeln(anonymousCmd + ' >> "' + logFile + '" 2>&1');
      if (sessionArgs) shr.writeln('if [ $? -ne 0 ]; then ' + fullCmd + ' >> "' + logFile + '" 2>&1; fi');
      shr.writeln('if [ -f "' + ffmpegPath + '" ]; then');
      shr.writeln('  for f in "' + downloadFolder.fsName + '"/media_*.jpg "' + downloadFolder.fsName + '"/media_*.jpeg "' + downloadFolder.fsName + '"/media_*.png "' + downloadFolder.fsName + '"/media_*.webp; do');
      shr.writeln('    [ -f "$f" ] || continue');
      shr.writeln('    case "$f" in *_clean.png) continue;; esac');
      shr.writeln('    base="${f%.*}"');
      shr.writeln('    "' + ffmpegPath + '" -y -i "$f" -frames:v 1 -update 1 "${base}_clean.png" >> "' + logFile + '" 2>&1');
      shr.writeln('  done');
      shr.writeln('fi');

      shr.writeln('DGVID=$(find "' + downloadFolder.fsName + '" -maxdepth 1 -type f -name "media_*.mp4" ! -name "*_h264.mp4" | head -n 1)');
      shr.writeln('DGAUDIO=$(find "' + downloadFolder.fsName + '" -maxdepth 1 -type f -name "media_*.m4a" | head -n 1)');
      shr.writeln('if [ -x "' + ffprobePath + '" ] && [ -f "$DGVID" ]; then');
      shr.writeln('  DGCODEC=$("' + ffprobePath + '" -v error -select_streams v:0 -show_entries stream=codec_name -of default=nw=1:nk=1 "$DGVID")');
      shr.writeln('  echo "[HeyGram] codec de video detectado: $DGCODEC" >> "' + logFile + '"');
      shr.writeln('  echo "[HeyGram] faixa de audio separada: $DGAUDIO" >> "' + logFile + '"');
      shr.writeln('  if [ -n "$DGCODEC" ] && [ "$DGCODEC" != "h264" ]; then');
      shr.writeln('    echo "[HeyGram] recodificando para H.264..." >> "' + logFile + '"');
      shr.writeln('    if [ -f "$DGAUDIO" ]; then');
      shr.writeln('      "' + ffmpegPath + '" -y -i "$DGVID" -i "$DGAUDIO" -map 0:v:0 -map 1:a:0 -c:v libx264 -preset veryfast -crf 18 -pix_fmt yuv420p -c:a aac -b:a 192k -movflags +faststart "' + downloadFolder.fsName + '/media_001_h264.mp4" >> "' + logFile + '" 2>&1');
      shr.writeln('    else');
      shr.writeln('      "' + ffmpegPath + '" -y -i "$DGVID" -map 0:v:0 -map "0:a:0?" -c:v libx264 -preset veryfast -crf 18 -pix_fmt yuv420p -c:a aac -b:a 192k -movflags +faststart "' + downloadFolder.fsName + '/media_001_h264.mp4" >> "' + logFile + '" 2>&1');
      shr.writeln('    fi');
      shr.writeln('  elif [ "$DGCODEC" = "h264" ] && [ -f "$DGAUDIO" ]; then');
      shr.writeln('    echo "[HeyGram] mesclando a faixa de audio ao H.264..." >> "' + logFile + '"');
      shr.writeln('    "' + ffmpegPath + '" -y -i "$DGVID" -i "$DGAUDIO" -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -movflags +faststart "' + downloadFolder.fsName + '/media_001_h264.mp4" >> "' + logFile + '" 2>&1');
      shr.writeln('  fi');
      shr.writeln('  if [ -f "' + downloadFolder.fsName + '/media_001_h264.mp4" ]; then');
      shr.writeln('    rm -f "$DGVID" "$DGAUDIO"');
      shr.writeln('    mv -f "' + downloadFolder.fsName + '/media_001_h264.mp4" "' + downloadFolder.fsName + '/media_001.mp4"');
      shr.writeln('  fi');
      shr.writeln('fi');
      shr.writeln('if [ -f "' + downloadFolder.fsName + '/media_001.mp4" ]; then');
      shr.writeln('  echo "[HeyGram] streams finais:" >> "' + logFile + '"');
      shr.writeln('  "' + ffprobePath + '" -v error -show_entries stream=index,codec_type,codec_name,width,height,sample_rate,channels -of default=nw=1 "' + downloadFolder.fsName + '/media_001.mp4" >> "' + logFile + '" 2>&1');
      shr.writeln('fi');

      shr.writeln('for d in "' + downloadFolder.fsName + '"/media_*.description; do');
      shr.writeln('  [ -f "$d" ] || continue');
      shr.writeln('  mv -f "$d" "${d%.description}.txt"');
      shr.writeln('done');

      shr.writeln('echo DONE > "' + doneFile + '"');
      shr.close();
      shr.execute();
    }

    var jobFile = new File(tmp + s + "job_" + stamp + ".txt");
    jobFile.open("w");
    jobFile.write(downloadFolder.fsName);
    jobFile.close();
    return "OK|" + stamp;
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

// Devolve os arquivos baixados; o client classifica vídeo/thumbnail pela extensão.
function dg_poll(stamp, tmp, downloadPath) {
  try {
    var s = sep();
    var doneFile = new File(tmp + s + "done_" + stamp + ".txt");
    var logPath = getLogsDir() + s + "download_" + stamp + ".txt";
    var lastLine = readLastLine(logPath);

    if (doneFile.exists) {
      var folder = new Folder(downloadPath);
      var files = folder.getFiles("media_*");
      var paths = [];
      for (var j = 0; j < files.length; j++) {
        if (!(files[j] instanceof File)) continue;
        var name = files[j].name;
        if (/\.(txt|description|json|bat|vbs|sh|command|part|ytdl)$/i.test(name)) continue;
        paths.push(files[j].fsName);
      }
      if (paths.length === 0) {
        var tail = readLastLines(logPath, 12);
        return "FAILED|" + tail + "||" + logPath;
      }
      return "DONE|" + paths.join("\n");
    }

    return "RUNNING|" + lastLine;
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

// Abre o log bruto no editor padrão do sistema (o tail de 12 linhas do painel raramente basta).
function dg_openLog(stamp) {
  try {
    var tmp = getWorkDir();
    var logs = getLogsDir();
    var s = sep();
    var candidates = [
      logs + s + "download_" + stamp + ".txt",
      logs + s + "analysis_" + stamp + ".txt",
      logs + s + "install_" + stamp + ".txt",
      tmp + s + "log_" + stamp + ".txt",
      tmp + s + stamp + "_log.txt",
      tmp + s + "install_log_" + stamp + ".txt"
    ];
    for (var i = 0; i < candidates.length; i++) {
      var f = new File(candidates[i]);
      if (f.exists) { f.execute(); return "OK|" + f.fsName; }
    }
    return dg_openLatestLog();
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

// Cancela um download: taskkill filtra pelo título `HeyGram-<stamp>` que o .bat
// define, derrubando cmd + processos filhos (/T). O `timeout` antes do rmdir
// evita falhar por arquivos ainda travados pelo processo morrendo.
function dg_cancelDownload(stamp) {
  try {
    if (!isWindows()) return "ERROR: Cancelamento ainda não suportado no macOS.";

    var tmp = getWorkDir();
    var s = sep();

    var downloadPath = "";
    try {
      var jobFile = new File(tmp + s + "job_" + stamp + ".txt");
      if (jobFile.exists) {
        jobFile.open("r");
        downloadPath = jobFile.read().replace(/^\s+|\s+$/g, "");
        jobFile.close();
      }
    } catch (eJob) {}

    var killBat = new File(tmp + s + "kill_" + stamp + ".bat");
    killBat.open("w");
    killBat.writeln("@echo off");
    killBat.writeln('taskkill /FI "WINDOWTITLE eq HeyGram-' + stamp + '*" /T /F >nul 2>&1');

    // Só remove se o caminho for reconhecidamente nosso.
    if (downloadPath && /HeyGram[\\\/]Reels[\\\/]/i.test(downloadPath)) {
      killBat.writeln("timeout /t 2 /nobreak >nul 2>&1");
      killBat.writeln('rmdir /s /q "' + downloadPath + '" >nul 2>&1');
    }

    killBat.close();
    runHiddenWindows(killBat);
    return "OK";
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

function dg_pollDownloadByStamp(stamp) {
  try {
    var tmp = getWorkDir();
    var jobFile = new File(tmp + sep() + "job_" + stamp + ".txt");
    if (!jobFile.exists) return "ERROR: Download não encontrado.";
    jobFile.open("r");
    var downloadPath = jobFile.read();
    jobFile.close();
    return dg_poll(stamp, tmp, downloadPath);
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

// ===================== Helpers de nomes e bins =====================

function baseName(p) {
  var n = p.substring(p.lastIndexOf("/") + 1);
  n = n.substring(n.lastIndexOf("\\") + 1);
  return n;
}

function dg_jsonQuote(value) {
  return '"' + String(value === undefined || value === null ? "" : value)
    .replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n") + '"';
}

// O ExtendScript de algumas versões do Premiere não disponibiliza JSON.parse.
// A biblioteca só precisa ler o pequeno manifesto que o próprio HeyGram grava;
// portanto usamos um parser estrito de objeto JSON, sem executar conteúdo local.
function dg_skipJsonWhitespace(state) {
  while (state.i < state.text.length && /\s/.test(state.text.charAt(state.i))) state.i += 1;
}

function dg_parseJsonString(state) {
  if (state.text.charAt(state.i) !== '"') return null;
  state.i += 1;
  var out = "", ch, esc, hex;
  while (state.i < state.text.length) {
    ch = state.text.charAt(state.i++);
    if (ch === '"') return out;
    if (ch === "\\") {
      if (state.i >= state.text.length) return null;
      esc = state.text.charAt(state.i++);
      if (esc === '"' || esc === "\\" || esc === "/") out += esc;
      else if (esc === "b") out += "\b";
      else if (esc === "f") out += "\f";
      else if (esc === "n") out += "\n";
      else if (esc === "r") out += "\r";
      else if (esc === "t") out += "\t";
      else if (esc === "u") {
        hex = state.text.substr(state.i, 4);
        if (!/^[0-9a-fA-F]{4}$/.test(hex)) return null;
        out += String.fromCharCode(parseInt(hex, 16));
        state.i += 4;
      } else return null;
    } else {
      if (ch < " ") return null;
      out += ch;
    }
  }
  return null;
}

function dg_parseLibraryMeta(text) {
  var raw = String(text || "");
  if (!raw || raw.length > 65536) return null;
  var state = { text: raw, i: 0 }, out = {}, key, value;
  dg_skipJsonWhitespace(state);
  if (state.text.charAt(state.i++) !== "{") return null;
  dg_skipJsonWhitespace(state);
  if (state.text.charAt(state.i) === "}") { state.i += 1; return out; }
  while (state.i < state.text.length) {
    dg_skipJsonWhitespace(state);
    key = dg_parseJsonString(state);
    if (key === null) return null;
    dg_skipJsonWhitespace(state);
    if (state.text.charAt(state.i++) !== ":") return null;
    dg_skipJsonWhitespace(state);
    value = dg_parseJsonString(state);
    if (value === null) return null; // o manifesto oficial possui somente strings
    if (/^(title|thumbnail|duration|url|handle)$/.test(key)) out[key] = value;
    dg_skipJsonWhitespace(state);
    if (state.text.charAt(state.i) === "}") { state.i += 1; break; }
    if (state.text.charAt(state.i++) !== ",") return null;
  }
  dg_skipJsonWhitespace(state);
  return state.i === state.text.length ? out : null;
}

// Remove caracteres que atrapalham a exibição de nomes de bin/item no Premiere.
function sanitizeName(str) {
  if (!str) return "";
  return str.replace(/[\\\/:\*\?"<>\|]/g, "").replace(/^\s+|\s+$/g, "");
}

// Versão só-ASCII pra nomes de PASTA: o .bat é gravado na codepage do Windows,
// não UTF-8, então acentos quebram o caminho. Acentos são transliterados; o
// resto vira "_". O nome bonito continua no bin do Premiere.
function asciiFolderName(str) {
  var from = "áàâãäåÁÀÂÃÄÅéèêëÉÈÊËíìîïÍÌÎÏóòôõöÓÒÔÕÖúùûüÚÙÛÜçÇñÑýÿÝ";
  var to   = "aaaaaaAAAAAAeeeeEEEEiiiiIIIIoooooOOOOOuuuuUUUUcCnNyyY";
  var out = "";
  var clean = sanitizeName(str);
  for (var i = 0; i < clean.length; i++) {
    var ch = clean.charAt(i);
    var idx = from.indexOf(ch);
    if (idx !== -1) { out += to.charAt(idx); continue; }
    out += /[A-Za-z0-9 ._-]/.test(ch) ? ch : "_";
  }
  out = out.replace(/_{2,}/g, "_").replace(/^\s+|\s+$/g, "");
  // Um perfil inteiramente não-latino (japonês, árabe, cirílico) viraria só
  // "_". Devolve vazio para o chamador cair no nome padrão.
  return /[A-Za-z0-9]/.test(out) ? out : "";
}

function getOrCreateBin(parentBin, name) {
  for (var i = 0; i < parentBin.children.numItems; i++) {
    var item = parentBin.children[i];
    if (item.type === ProjectItemType.BIN && item.name === name) return item;
  }
  return parentBin.createBin(name);
}

// ===================== Importar e inserir na timeline =====================
// Organização no projeto: HeyGram (bin raiz) > @perfil > media_001.mp4 (+ thumbnail).
// importPathsRaw: caminhos "||" a importar pro bin. timelineFilePath: arquivo pra
// inserir na timeline (vazio se nenhum).
function dg_importDownloadResult(importPathsRaw, timelineFilePath, isAudioOnly, profileName, jobStamp) {
  var safeStamp = String(jobStamp || ("manual_" + new Date().getTime())).replace(/[^A-Za-z0-9_-]/g, "_");
  var importLogPath = getLogsDir() + sep() + "download_" + safeStamp + ".txt";
  function importLog(message) { appendLogFile(importLogPath, "[Premiere] " + message); }
  try {
    importLog("=== INICIO DA IMPORTACAO ===");
    try { importLog("Versao do Premiere: " + app.version); } catch (eVersion) {}
    importLog("Perfil de destino: @" + String(profileName || "instagram").replace(/^@/, ""));
    importLog("Arquivo para timeline: " + (timelineFilePath || "(nenhum)"));
    importLog("Somente audio: " + (isAudioOnly ? "sim" : "nao"));

    var proj = app.project;
    if (!proj) {
      importLog("ERRO: Nenhum projeto aberto.");
      return "ERROR: Nenhum projeto aberto.";
    }
    try { importLog("Projeto: " + (proj.name || "(sem nome)")); } catch (eProject) {}

    var downGramBin = getOrCreateBin(proj.rootItem, "HeyGram");
    var cleanProfile = sanitizeName(profileName).replace(/^@/, "") || "instagram";
    var profileBin = getOrCreateBin(downGramBin, "@" + cleanProfile);

    var importPaths = importPathsRaw ? importPathsRaw.split("||") : [];
    if (importPaths.length === 0) {
      importLog("ERRO: Nenhum arquivo para importar.");
      return "ERROR: Nenhum arquivo para importar.";
    }

    for (var p = 0; p < importPaths.length; p++) {
      var importFile = new File(importPaths[p]);
      importLog("Arquivo[" + p + "]: " + importPaths[p] + " | existe=" + (importFile.exists ? "sim" : "NAO") + " | bytes=" + (importFile.exists ? importFile.length : 0));
    }

    var importResult = proj.importFiles(importPaths, true, profileBin, false);
    importLog("proj.importFiles retornou: " + String(importResult));

    var timelineStatus = "NO_TIMELINE_FILE";
    var videoItem = null;

    if (timelineFilePath) {
      // Prioriza o caminho real: o nome exibido pelo Premiere pode divergir após recodificação.
      videoItem = findProjectItemByMediaPath(profileBin, timelineFilePath) || findProjectItemByName(profileBin, baseName(timelineFilePath));

      // setScaleToFrameSize ("Definir como tamanho do quadro") precisa ser
      // aplicado no ITEM DO PROJETO antes da inserção — na timeline não tem efeito.
      if (videoItem) {
        try { videoItem.setScaleToFrameSize(); } catch (eScale) {}
      }

      var seq = proj.activeSequence;
      if (!seq) {
        timelineStatus = "NO_SEQUENCE";
      } else if (videoItem) {
        var playhead = seq.getPlayerPosition();
        var track = isAudioOnly ? seq.audioTracks[0] : seq.videoTracks[0];
        if (!track) {
          timelineStatus = "NO_TRACK";
        } else {
          try {
            var inserted = track.insertClip(videoItem, playhead.seconds);
            timelineStatus = inserted === false ? "INSERT_FAILED" : "OK";
          } catch (eInsert) {
            timelineStatus = "INSERT_ERROR:" + eInsert.toString();
          }
        }
      } else {
        timelineStatus = "ITEM_NOT_FOUND";
      }
    }
    importLog("Item de video localizado no projeto: " + (videoItem ? "sim" : "nao"));
    importLog("Status da timeline: " + timelineStatus);

    // Legenda como metadado do clipe, não como arquivo importado.
    var captionStatus = "NONE";
    var caption = readSidecarCaption(timelineFilePath);
    if (caption && videoItem) captionStatus = setClipDescription(videoItem, caption);
    importLog("Status da legenda: " + captionStatus);
    importLog("=== FIM DA IMPORTACAO ===");

    return "OK|" + profileBin.name + "|" + timelineStatus + "|" + captionStatus;
  } catch (e) {
    importLog("ERRO/EXCECAO: " + e.toString());
    return "ERROR: " + e.toString();
  }
}

// Lê o .txt de legenda irmão do vídeo (media_001.mp4 -> media_001.txt).
function readSidecarCaption(videoPath) {
  try {
    if (!videoPath) return "";
    var txtPath = videoPath.replace(/\.[A-Za-z0-9]+$/, "") + ".txt";
    var f = new File(txtPath);
    if (!f.exists) return "";
    f.open("r");
    var content = f.read();
    f.close();
    return content.replace(/^\s+|\s+$/g, "");
  } catch (e) {
    return "";
  }
}

// Escreve a legenda no campo "Descrição" (coluna do painel Projeto), em vez de
// importar o .txt — o Premiere não reconhece .txt como mídia importável.
function setClipDescription(projectItem, text) {
  try {
    if (!projectItem || !text) return "SKIP";

    if (ExternalObject.AdobeXMPScript === undefined) {
      ExternalObject.AdobeXMPScript = new ExternalObject("lib:AdobeXMPScript");
    }
    if (typeof XMPMeta === "undefined") return "NO_XMP";

    var ns = "http://ns.adobe.com/premierePrivateProjectMetaData/1.0/";
    var field = "Column.Intrinsic.Description";

    var xmp = new XMPMeta(projectItem.getProjectMetadata());
    xmp.setProperty(ns, field, text);
    projectItem.setProjectMetadata(xmp.serialize(), [field]);
    return "OK";
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

function findProjectItemByName(bin, name) {
  for (var i = 0; i < bin.children.numItems; i++) {
    var item = bin.children[i];
    if (item.name === name) return item;
    if (item.type === ProjectItemType.BIN) {
      var found = findProjectItemByName(item, name);
      if (found) return found;
    }
  }
  return null;
}

function findProjectItemByMediaPath(bin, mediaPath) {
  var wanted = String(mediaPath || "").replace(/\//g, "\\").toLowerCase();
  for (var i = 0; i < bin.children.numItems; i++) {
    var item = bin.children[i];
    try {
      if (item.type !== ProjectItemType.BIN && String(item.getMediaPath() || "").replace(/\//g, "\\").toLowerCase() === wanted) return item;
    } catch (ePath) {}
    if (item.type === ProjectItemType.BIN) {
      var found = findProjectItemByMediaPath(item, mediaPath);
      if (found) return found;
    }
  }
  return null;
}

function dg_insertExistingMedia(mediaPath, profileName) {
  try {
    var media = String(mediaPath || "");
    if (!media || !(new File(media)).exists) return "ERROR: O arquivo salvo não foi encontrado no disco.";
    return dg_importDownloadResult(media, media, false, profileName || "instagram", "library_" + String(new Date().getTime()));
  } catch (e) {
    return "ERROR: " + e.toString();
  }
}

function dg_listSavedMedia() {
  try {
    var files = [];
    function visit(folder) {
      if (!folder || !folder.exists || files.length >= 120) return;
      var children = folder.getFiles();
      for (var i = 0; i < children.length && files.length < 120; i++) {
        var child = children[i];
        if (child instanceof Folder) visit(child);
        else if (/\.(mp4|mov|m4v)$/i.test(child.name)) {
          var record = { path: child.fsName, title: "", thumbnail: "", duration: "—", url: "", handle: "" };
          var metaFile = new File(child.parent.fsName + sep() + ".heygram.json");
          if (metaFile.exists) {
            try {
              metaFile.open("r");
              var metaText = metaFile.read();
              metaFile.close();
               var meta = dg_parseLibraryMeta(metaText);
               if (meta) {
                 record.title = meta.title || "";
                 record.thumbnail = meta.thumbnail || "";
                 record.duration = meta.duration || "—";
                 record.url = meta.url || "";
                 record.handle = meta.handle || "";
               }
            } catch (eMeta) {}
          }
          // Downloads mais antigos não possuem .heygram.json. A legenda é um
          // fallback humano melhor do que exibir media_001, e a thumbnail
          // limpa local permanece disponível sem depender da rede.
          var stem = child.name.replace(/\.[A-Za-z0-9]+$/, "");
          if (!record.title) {
            var caption = new File(child.parent.fsName + sep() + stem + ".txt");
            if (caption.exists) {
              try { caption.open("r"); record.title = caption.read().split(/[\r\n]+/)[0]; caption.close(); } catch (eCaption) {}
            }
          }
          if (!record.thumbnail) {
            var image = new File(child.parent.fsName + sep() + stem + "_clean.png");
            if (!image.exists) image = new File(child.parent.fsName + sep() + stem + ".jpg");
            if (!image.exists) image = new File(child.parent.fsName + sep() + stem + ".png");
            if (image.exists) record.thumbnail = "file:///" + image.fsName.replace(/\\/g, "/");
          }
          files.push(record);
        }
      }
    }
    visit(new Folder(getMediaDir()));
    var json = "[";
    for (var j = 0; j < files.length; j++) {
      if (j) json += ",";
      var item = files[j];
      json += '{"path":' + dg_jsonQuote(item.path) + ',"title":' + dg_jsonQuote(item.title) + ',"thumbnail":' + dg_jsonQuote(item.thumbnail) + ',"duration":' + dg_jsonQuote(item.duration) + ',"url":' + dg_jsonQuote(item.url) + ',"handle":' + dg_jsonQuote(item.handle) + '}';
    }
    return "OKJSON|" + json + "]";
  } catch (e) { return "ERROR: " + e.toString(); }
}
